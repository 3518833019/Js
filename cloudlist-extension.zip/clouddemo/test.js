const WebSocket = require('ws');
function client(name, room) {
  return new Promise(resolve => {
    const ws = new WebSocket('ws://127.0.0.1:8090/');
    const got = [];
    ws.on('open', () => {
      ws.send(JSON.stringify({ method: 'handshake', project_id: room, user: name }));
      setTimeout(() => {
        ws.send(JSON.stringify({
          method: 'set', name: '☁ cloudlist:list1',
          value: JSON.stringify({ v: 1, items: ['苹果', '香蕉', name] })
        }));
      }, 300);
    });
    ws.on('message', m => {
      const o = JSON.parse(m.toString());
      if (o.method === 'set') got.push(o.value);
    });
    setTimeout(() => { ws.close(); resolve({ name, got }); }, 900);
  });
}
(async () => {
  const a = await client('A', 'room1');
  const b = await client('B', 'room1');
  const c = await client('C', 'room2');
  await new Promise(r => setTimeout(r, 400));
  console.log('A 收到:', a.got);
  console.log('B 收到:', b.got);
  console.log('C(不同房间) 收到:', c.got);
})();
