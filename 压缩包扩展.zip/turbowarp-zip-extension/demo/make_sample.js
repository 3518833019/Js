// 生成一个用于演示/测试的 sample.zip
// 用法：node make_sample.js  （需要 node >= 14）
const fs = require("fs");
const path = require("path");

// 优先用 adm-zip，回退到手写 ZIP（仅演示，不推荐）
let zip;
try {
  const AdmZip = require("adm-zip");
  zip = { kind: "adm-zip", arc: new AdmZip() };
} catch (e) {
  zip = { kind: "hand-zip", files: [] };
}

const files = {
  "readme.txt": "Hello from TurboWarp ZIP extension!\n这是一行中文。\nEmoji: 📦🚀",
  "config.json": JSON.stringify(
    { version: 1, author: "TurboWarp", features: ["import", "read", "write", "export"] },
    null, 2
  ),
  "data/score.csv": "name,score\nAlice,100\nBob,95\n",
  "data/empty.txt": "",
  "assets/": null, // 目录
  "assets/note.txt": "I'm inside assets folder."
};

if (zip.kind === "adm-zip") {
  Object.keys(files).forEach(function (name) {
    if (files[name] === null) {
      zip.arc.addFile(name, Buffer.alloc(0)); // 目录条目
    } else {
      zip.arc.addFile(name, Buffer.from(files[name], "utf-8"));
    }
  });
  zip.arc.writeZip(path.join(__dirname, "sample.zip"));
  console.log("✅ 已生成 demo/sample.zip（adm-zip）");
} else {
  // 极简 ZIP 手写（仅 Store 压缩，仅用于测试）
  function storeFile(name, content) {
    const nameBytes = Buffer.from(name, "utf-8");
    const data = Buffer.from(content, "utf-8");
    const crc = 0; // 省略 CRC 计算，仅演示
    const header = Buffer.alloc(30);
    header.writeUInt32LE(0x04034b50, 0);      // local file header signature
    header.writeUInt16LE(20, 4);              // version needed
    header.writeUInt16LE(0x0800, 6);          // flag: UTF-8 标志位
    header.writeUInt16LE(0, 8);               // compression: stored
    header.writeUInt32LE(0, 10);              // mtime
    header.writeUInt32LE(crc, 14);            // crc32
    header.writeUInt32LE(data.length, 18);     // compressed size
    header.writeUInt32LE(data.length, 22);     // uncompressed size
    header.writeUInt16LE(nameBytes.length, 26);
    header.writeUInt16LE(0, 28);              // extra field
    return Buffer.concat([header, nameBytes, data]);
  }
  let parts = [];
  Object.keys(files).forEach(function (name) {
    if (files[name] === null) {
      parts.push(storeFile(name, "")); // 目录
    } else {
      parts.push(storeFile(name, files[name]));
    }
  });
  // 简单拼接，不含中央目录（不完整 ZIP，仅占位）
  fs.writeFileSync(path.join(__dirname, "sample.zip"), Buffer.concat(parts));
  console.log("⚠️ 已生成 demo/sample.zip（手写占位，请用 adm-zip 版本）");
}
