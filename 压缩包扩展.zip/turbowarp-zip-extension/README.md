# TurboWarp 扩展：ZIP 导入 / 导出 / 读取（完整 CRUD）

一个为 **TurboWarp Desktop** 编写的自定义扩展，让你在积木式编程环境中直接操作 ZIP 压缩包：
**导入（Import）→ 读取（Read）→ 写入/修改（Create/Update/Delete）→ 导出（Export）**。

## 📦 交付文件

| 文件 | 说明 |
|------|------|
| `zip-extension.js` | **唯一需要加载的扩展文件**（单文件自包含，符合 TurboWarp Gallery 规范） |
| `demo/README.md` | 示例脚本 + 24 个积木速查 + 错误码表 + 测试清单 |
| `README.md` | 本文件 |

> 依赖说明：扩展内置 **JSZip**（通过 CDN 动态加载，离线请自行内联）。Desktop 非沙箱环境下会尝试使用 **adm-zip**（纯 JS、零原生依赖）以获得同步、更稳的体验。两者都不需要 `npm install`。

## 🚀 安装步骤（TurboWarp Desktop）

1. 下载本仓库的 `zip-extension.js`
2. 打开 **TurboWarp Desktop**（[官网](https://turbowarp.org/desktop)）
3. 新建或打开一个项目
4. 点击左下角 **「添加扩展」** → 拉到最底部 → **「自定义扩展」**
5. 在弹出的对话框中选择 **「文件」** 标签 → 选择 `zip-extension.js`
6. **务必勾选「Run extension without sandbox」（以非沙箱模式运行）** ← 关键！
7. 确认后，积木栏会出现橙色的 **「ZIP 导入/导出/读取」** 分类

> 若使用网页版 [turbowarp.org](https://turbowarp.org/)，同样可加载，但受浏览器沙箱限制：
> - ✅ 可用：文件选择器导入、读取、修改、Base64 导出、Blob 下载
> - ❌ 不可用：直接读写任意磁盘路径（`保存到 [PATH]` 会返回 `ERR_NO_FILESYSTEM` 错误码，不会崩溃）

## 🧱 积木清单（24 个）

### ① 导入 / 生命周期
| 积木 | 类型 | 作用 |
|------|------|------|
| 从文件打开 ZIP | 命令 | 弹出系统文件选择器，读取 `.zip` 到内存 |
| 创建空 ZIP | 命令 | 新建空白归档 |
| 从 Base64 打开 ZIP [DATA] | 命令 | 从变量/网络获得的 Base64 字符串打开 |
| 创建空 ZIP 命名为 [NAME] | 命令 | 新建空白归档并指定名字（自动加 `.zip` 后缀，过滤非法字符） |
| 从文件创建空 ZIP 命名为 [NAME] | 命令 | 同上，语义上用于"先命名再导入"的流程 |
| 把 ZIP 文件导入到当前压缩包 [MODE] | 命令 | 从文件选择器选取一个 ZIP，合并进当前归档 |
| 把 Base64 的 ZIP [DATA] 导入到当前压缩包 [MODE] | 命令 | 把 Base64 编码的 ZIP 合并进当前归档 |
| 已打开 ZIP？ | 布尔 | 状态判断 |
| ZIP 引擎 | 报告 | `adm-zip`（Desktop）或 `jszip`（网页） |
| 可使用本地文件系统？ | 布尔 | Desktop 非沙箱为 `true` |

### ② 读取
| 积木 | 类型 | 作用 |
|------|------|------|
| ZIP 条目数 | 数字 | 成员总数 |
| 索引 [INDEX] 的条目名 | 字符串 | 按序号取名字（从 1 开始） |
| 条目列表（JSON） | 字符串 | `[{"path":...,"size":...,"compressedSize":...,"directory":...}]` |
| ZIP 包含条目 [PATH]？ | 布尔 | 存在性判断 |
| 条目 [PATH] 的未压缩大小 | 数字 | 字节数，不存在返回 `-1` |
| 条目 [PATH] 是文件夹？ | 布尔 | 目录判断 |
| 读取 [PATH] 为文本 | 字符串 | 按 UTF-8 解码（适合 `.txt/.json/.csv/.js`） |
| 读取 [PATH] 为 Base64 | 字符串 | 二进制安全（适合 `.png/.wav/.sb3`） |

### ③ 写入（CRUD 的 C/U/D）
| 积木 | 类型 | 作用 |
|------|------|------|
| 添加文本条目 [PATH] 内容 [TEXT] | 命令 | 新建或覆盖文本文件 |
| 添加二进制条目 [PATH] 内容 Base64 [DATA] | 命令 | 新建或覆盖二进制文件 |
| 删除条目 [PATH] | 命令 | Delete |
| 重命名条目 [OLD] 为 [NEW] | 命令 | Rename（copy-on-write） |

### ④ 导出
| 积木 | 类型 | 作用 |
|------|------|------|
| 下载 ZIP 为 [NAME] | 命令 | 触发浏览器/系统下载（跨平台） |
| ZIP 的 Base64 | 字符串 | 用于网络传输或存入变量 |
| 将 ZIP 保存到 [PATH] | 命令 | **仅 Desktop 非沙箱**：直接写磁盘路径 |

### ⑤ 配置 / 诊断
| 积木 | 类型 | 作用 |
|------|------|------|
| 设置最大压缩包字节 [ARCHIVE] 最大单文件字节 [ENTRY] | 命令 | 默认 100MB / 50MB，防内存溢出 |
| 最后 ZIP 错误 | 字符串 | 返回错误码，**读后自动清空** |
| 上次导入的条目数 | 数字 | `importZipInto` / `importZipBase64Into` 后返回本次导入了多少个 |
| 上次导入跳过的条目数 | 数字 | 同上，返回因冲突被跳过的条目数 |

## 🆕 v1.1 新功能：命名空包 + 导入合并

### 创建空压缩包时自定义名字

```
创建空 ZIP 命名为 [我的资源包]   ← 积木参数 NAME
```

- 自动过滤非法字符（`/\:*?"<>|`）为 `_`
- 自动补全 `.zip` 后缀
- 名字存储在内部，导出时作为默认文件名

### 把 ZIP 导入到当前压缩包（合并）

```
把 ZIP 文件导入到当前压缩包 [跳过已存在 / 覆盖已存在 / 全部重命名避免冲突]
```

三种冲突处理模式：

| 模式 | 行为 | 适用场景 |
|------|------|----------|
| **跳过已存在**（默认） | 同名文件不导入，保留当前归档中的版本 | 增量合并，不覆盖已有内容 |
| **覆盖已存在** | 同名文件用新内容替换 | 完全用新包覆盖旧文件 |
| **全部重命名避免冲突** | 冲突的文件自动加 `(1)`、`(2)` 后缀 | 保留两个版本 |

合并后可用 `上次导入的条目数` 和 `上次导入跳过的条目数` 积木获取结果统计。

### 典型用法：把多个 ZIP 合并成一个

```
当 绿旗 被点击
    创建空 ZIP 命名为 "合集"
    把 ZIP 文件导入到当前压缩包 [跳过已存在]    // 第一次：选 part1.zip
    把 ZIP 文件导入到当前压缩包 [跳过已存在]    // 第二次：选 part2.zip
    说 (连接 "导入了 " (连接 (上次导入的条目数) " 个文件")) (2) 秒
    下载 ZIP 为 "合集.zip"
```




| 风险 | 防护 |
|------|------|
| **Zip-Slip** 路径遍历（`../`、`/etc/passwd`） | `normalizeName()` 拒绝 NUL、绝对路径、`..` |
| **压缩炸弹**（1000:1 高压缩比） | 限制压缩包总大小、单文件大小、压缩比 |
| 二进制被当文本读（乱码/丢字节） | 显式区分「文本」与「Base64」两种读取模式 |
| 中文/Emoji 文件名乱码 | 写入端强制 UTF-8 标志位（通用位 11） |
| 大文件阻塞渲染 | 异步 Promise 积木 + 可配置上限 |
| 扩展抛错导致脚本断裂 | 所有错误转为错误码字符串，积木永不 throw |

## 🏗️ 架构：单文件、双引擎、运行时降级

```
                    ┌─ 探测 typeof require === 'function'
                    │       ├─ 成功 → adm-zip + fs（Desktop 非沙箱，同步、可直接存盘）
                    │       └─ 失败
TurboWarp 加载 ──►  │              └─ JSZip + 文件选择器 + Blob 下载（网页版 / 沙箱）
                    │
                    └─ 统一 Promise 接口：open / entries / read / add / remove / generate
```

**为什么不用 Node 的 `zlib` 手写 ZIP？**
`zlib` 只提供 Deflate 原语，不包含 ZIP 容器格式（本地文件头、中央目录、Data Descriptor、CRC32、ZIP64、UTF-8 标志）。手工实现无法满足多工具互操作、大文件、随机读取与安全校验。

**为什么不依赖 Electron 的 `dialog`？**
`dialog` 是 Electron **主进程**模块，TurboWarp 的 preload 并未把它桥接到渲染器全局。扩展里直接 `require('electron').dialog` 不可靠。故统一使用隐藏 `<input type="file">` + `Blob` 下载，跨平台且稳定。

## 📝 典型用法示例

**做一个「ZIP 配置编辑器」**：导入 `config.zip` → 读取 `config.json`（可再接一个 JSON 扩展解析）→ 改值 → 添加日志文件 → 导出 `config.edited.zip`。

**做一个「资源打包器」**：把多个「读取 [PATH] 为 Base64」的结果拼成 data URI，用于精灵造型/声音；或用「添加二进制条目」把截图、录音打进 ZIP。

**做一个「SB3 拆包工具」**：`.sb3` 本质就是 ZIP。可用「条目列表」「读取为文本」查看 `project.json`，用「下载 ZIP 为」另存为 `.sb3`。

## ⚠️ 已知限制

1. **不能保证**网页版直接访问任意磁盘路径（浏览器安全模型）
2. **不能保证**所有 Desktop 版本都有 `require('fs')`（需在「非沙箱」下运行）
3. **不能保证** `File.path`、`Scratch.gui.saveProjectSb3` 等内部 API 可用（未使用）
4. **不依赖** `child_process`、不执行 `eval`、不做自动磁盘解压（防 Zip-Slip）

## 📄 许可证

- 扩展源码：GPLv3
- 内嵌 JSZip：MIT License（[jszip](https://github.com/Stuk/jszip/blob/master/LICENSE.markdown)）
- 推荐 adm-zip：MIT License

符合 [TurboWarp Extensions 提交规范](https://github.com/TurboWarp/extensions/blob/master/CONTRIBUTING.md)（单文件自包含、兼容 GPLv3）。

## 🔗 参考

- [TurboWarp 扩展开发：Hello World](https://docs.turbowarp.org/development/extensions/hello-world)
- [TurboWarp 非沙箱扩展](https://docs.turbowarp.org/development/extensions/unsandboxed)
- [TurboWarp 积木输入 / 参数类型](https://docs.turbowarp.org/development/extensions/inputs)
- [TurboWarp 异步积木](https://docs.turbowarp.org/development/extensions/async)
- [TurboWarp 扩展兼容性](https://docs.turbowarp.org/development/extensions/compatibility)
- [JSZip](https://stuk.github.io/jszip/)
- [adm-zip](https://www.npmjs.com/package/adm-zip)
- [ZIP 规范 APPNOTE / UTF-8 文件名标志（通用位 11）](https://sources.debian.org/src/node-jszip/3.5.0%2Bdfsg-2/docs/APPNOTE.TXT/)
- [Zip-Slip 路径遍历漏洞](https://hacktricks.wiki/generic-hacking/archive-extraction-path-traversal.html)
