/**
 * 云列表同步 —— 私人服务器
 * =============================
 * 安装依赖：  npm install ws
 * 启动：      node run-server.js
 *
 * 默认监听 0.0.0.0:8080，账号 admin / 123456
 * 可通过环境变量覆盖：PORT=9000 USER=myname PASS=mypassword node run-server.js
 */
const http = require('http');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');

// ── 配置 ─────────────────────────────────────────────
const PORT = parseInt(process.env.PORT, 10) || 8080;
const HOST = process.env.HOST || '0.0.0.0';

// 合法账号表：username -> password。可扩展成多用户
const ACCOUNTS = {
    [process.env.USER || 'admin']: process.env.PASS || '123456'
};

// 服务端保存的所有列表：{ listName -> { items:[...], visible:true } }
const lists = Object.create(null);

// 当前在线客户端：{ clientId -> ws }
const clients = Object.create(null);

// ── HTTP 服务（提供简单状态页）──────────────────────
const server = http.createServer((req, res) => {
    if (req.url === '/health') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
            ok: true,
            clients: Object.keys(clients).length,
            lists: Object.keys(lists).length,
            uptime: Math.floor(process.uptime())
        }));
        return;
    }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(
        '<h2>云列表同步私人服务器</h2>' +
        '<p>在线客户端：' + Object.keys(clients).length + '</p>' +
        '<p>已登记列表：' + Object.keys(lists).length + '</p>' +
        '<p>用 WebSocket 连接此地址，并在握手消息中提供 username / password。</p>'
    );
});

// ── WebSocket 服务 ──────────────────────────────────
const wss = new WebSocketServer({ server });

function makeId() {
    return crypto.randomBytes(6).toString('hex');
}

function broadcast(msg, exceptId) {
    const data = JSON.stringify(msg);
    for (const id in clients) {
        if (id === exceptId) continue;
        const ws = clients[id];
        if (ws.readyState === 1 /* OPEN */) {
            try { ws.send(data); } catch (e) {}
        }
    }
}

function sendSnapshot(ws) {
    const payload = { t: 'snapshot', lists: {} };
    for (const name in lists) {
        if (!Object.prototype.hasOwnProperty.call(lists, name)) continue;
        const m = lists[name];
        payload.lists[name] = {
            items: m.items.slice(),
            visible: m.visible !== false
        };
    }
    if (ws.readyState === 1) {
        try { ws.send(JSON.stringify(payload)); } catch (e) {}
    }
}

wss.on('connection', (ws) => {
    const clientId = makeId();
    let authed = false;

    ws.on('message', (raw) => {
        let msg;
        try { msg = JSON.parse(raw.toString()); } catch (e) { return; }
        if (!msg || !msg.t) return;

        // 握手 / 登录
        if (msg.t === 'hello') {
            const u = msg.username || '';
            const p = msg.password || '';
            if (ACCUNTS_OK(u, p)) {
                authed = true;
                clients[clientId] = ws;
                ws.send(JSON.stringify({
                    t: 'welcome',
                    clientId: clientId,
                    user: u,
                    proto: 1
                }));
                // 登录成功 → 把当前全量快照推给新客户端
                sendSnapshot(ws);
            } else {
                ws.send(JSON.stringify({ t: 'authFailed', reason: '用户名或密码错误' }));
                try { ws.close(); } catch (e) {}
            }
            return;
        }

        if (!authed) return; // 未登录只接受 hello

        switch (msg.t) {
            case 'listChange': {
                const name = msg.name;
                if (!name) return;
                const m = (lists[name] = lists[name] || { items: [], visible: true });
                const list = m.items;
                switch (msg.type) {
                    case 'set': {
                        const idx = clampIndex(msg.index, list.length);
                        list[idx - 1] = String(msg.value == null ? '' : msg.value);
                        break;
                    }
                    case 'insert': {
                        const idx = clampIndex(msg.index, list.length + 1);
                        list.splice(idx - 1, 0, String(msg.value == null ? '' : msg.value));
                        break;
                    }
                    case 'deleteItem': {
                        if (list.length === 0) return;
                        const idx = clampIndex(msg.index, list.length);
                        list.splice(idx - 1, 1);
                        break;
                    }
                    case 'replaceAll': {
                        const arr = Array.isArray(msg.items) ? msg.items : [];
                        m.items = arr.map(x => String(x == null ? '' : x));
                        break;
                    }
                    case 'length': {
                        const target = Math.max(0, Math.floor(Number(msg.length)));
                        while (list.length < target) list.push('');
                        list.length = target;
                        break;
                    }
                }
                broadcast(msg, clientId);
                break;
            }
            case 'listCreated': {
                const name = msg.name;
                if (!name) return;
                const m = lists[name] || (lists[name] = { items: [], visible: true });
                if (Array.isArray(msg.items)) {
                    m.items = msg.items.map(x => String(x == null ? '' : x));
                }
                m.visible = (msg.visible !== false);
                broadcast(msg, clientId);
                break;
            }
            case 'listDeleted': {
                const name = msg.name;
                delete lists[name];
                broadcast(msg, clientId);
                break;
            }
            case 'listVisibility': {
                const name = msg.name;
                const m = lists[name];
                if (!m) return;
                m.visible = !!msg.visible;
                broadcast(msg, clientId);
                break;
            }
        }
    });

    ws.on('close', () => {
        delete clients[clientId];
    });

    ws.on('error', () => {});
});

function ACCUNTS_OK(u, p) {
    return ACCOUNTS[u] === p;
}
function clampIndex(v, len) {
    let n = Math.floor(Number(v));
    if (!isFinite(n) || n < 1) n = 1;
    if (n > len) n = len;
    if (len < 1) n = 1;
    return n;
}

server.listen(PORT, HOST, () => {
    console.log('云列表同步私人服务器已启动');
    console.log('  地址：ws://' + HOST + ':' + PORT);
    console.log('  账号：' + Object.keys(ACCOUNTS).join(', '));
    console.log('  提示：生产环境请通过反向代理（Nginx/Caddy）配置 HTTPS/WSS');
});
