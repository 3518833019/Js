// 验证 pako 桥接：用内联 JSZipInline + pako 解压 zlib 生成的 Deflate ZIP
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const zlib = require("zlib");

// 准备 pako（Node 端直接 require，模拟浏览器全局）
const pako = require("pako");

const sandbox = {
  window: {}, Uint8Array, ArrayBuffer, DataView,
  TextEncoder: require("util").TextEncoder,
  TextDecoder: require("util").TextDecoder,
  pako: pako,
  console, require, module: { exports: {} }, Buffer, Math, JSON, Date, Promise, Array, String, Number, Object, setTimeout
};
sandbox.window.pako = pako;
vm.createContext(sandbox);

// 1) 加载桥接
const bridge = fs.readFileSync(path.join(__dirname, "..", "pako-bridge.js"), "utf-8");
vm.runInContext(bridge, sandbox);
vm.runInContext("PakoBridge.install(window.pako);", sandbox);

// 2) 加载扩展（内含 JSZipInline）
const extSrc = fs.readFileSync(path.join(__dirname, "..", "zip-extension.js"), "utf-8");
vm.runInContext(extSrc, sandbox);

// 3) 用 zlib 生成 Deflate ZIP
function makeDeflateZip() {
  const tmp = path.join(__dirname, "_p");
  fs.mkdirSync(tmp, { recursive: true });
  fs.writeFileSync(path.join(tmp, "hello.txt"), "pako 桥接测试 🎯 中文 emoji");
  fs.writeFileSync(path.join(tmp, "bin.bin"), Buffer.from([10,20,30,40,250]));
  const out = path.join(__dirname, "_pako.zip");
  const { execSync } = require("child_process");
  execSync(`cd ${tmp} && zip -q ${out} . -x "*.DS_Store"`, { stdio: "pipe" });
  const buf = fs.readFileSync(out);
  fs.unlinkSync(out); fs.rmSync(tmp, { recursive: true, force: true });
  return buf;
}

(async () => {
  const JSZipInline = sandbox.window.JSZipInline;
  const zip = makeDeflateZip();
  console.log("测试 ZIP:", zip.length, "字节 (Deflate)");

  const arc = await JSZipInline.loadAsync(zip.buffer);
  const names = [];
  arc.forEach(n => names.push(n));
  console.log("✅ 条目:", names.join(", "));
  console.log("✅ hello.txt =", new TextDecoder().decode(await arc.file("hello.txt").async("uint8array")));
  console.log("✅ bin.bin =", Buffer.from(await arc.file("bin.bin").async("uint8array")).toString("hex"));
  console.log("\n🎉 pako 桥接生效：内联 JSZipInline 现已能解任意标准 Deflate ZIP");
})().catch(e => { console.error("❌", e); process.exit(1); });
