const WebSocket = require('ws');
function login(name, pass) {
  return new Promise(res => {
    const ws = new WebSocket('ws://localhost:8080');
    const msgs = [];
    ws.on('open', () => ws.send(JSON.stringify({t:'hello', username:name, password:pass})));
    ws.on('message', m => { msgs.push(JSON.parse(m.toString())); });
    setTimeout(() => res({ws, msgs}), 500);
  });
}
(async () => {
  const A = await login('admin','123456');
  const B = await login('admin','123456');
  console.log('A 登录回执:', A.msgs.map(m=>m.t).join(','));
  console.log('B 登录回执:', B.msgs.map(m=>m.t).join(','));
  console.log('B 初始快照:', JSON.stringify(B.msgs.find(m=>m.t==='snapshot').lists));

  A.ws.send(JSON.stringify({t:'listCreated', name:'分数榜', items:[100,200,300], visible:true, clientId:'A'}));
  await new Promise(r=>setTimeout(r,250));
  console.log('B 收到创建:', B.msgs.filter(m=>m.t==='listCreated').map(m=>m.name).join(','));

  A.ws.send(JSON.stringify({t:'listChange', type:'set', name:'分数榜', index:2, value:999, clientId:'A'}));
  await new Promise(r=>setTimeout(r,250));

  A.ws.send(JSON.stringify({t:'listVisibility', name:'分数榜', visible:false, clientId:'A'}));
  await new Promise(r=>setTimeout(r,250));
  console.log('B 收到隐藏:', B.msgs.filter(m=>m.t==='listVisibility').map(m=>JSON.stringify(m)).join(' | '));

  A.ws.send(JSON.stringify({t:'listDeleted', name:'分数榜', clientId:'A'}));
  await new Promise(r=>setTimeout(r,250));
  console.log('B 收到删除:', B.msgs.filter(m=>m.t==='listDeleted').map(m=>m.name).join(','));

  const C = await login('admin','bad');
  console.log('错密测试:', C.msgs.map(m=>m.t+':'+m.reason).join(' | '));

  A.ws.close(); B.ws.close(); C.ws.close();
  process.exit(0);
})();
