// 测试新功能：createZip 命名 + importZipInto 合并
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const zlib = require("zlib");

const Scratch = {
  extensions: { register(inst){ Scratch._reg = inst; }, unsandboxed: true, _reg: null },
  ArgumentType: { STRING: "string", NUMBER: "number", BOOLEAN: "boolean" },
  BlockType: { COMMAND: "command", REPORTER: "reporter", BOOLEAN: "boolean", HAT: "hat" }
};
const sandbox = {
  window:{ Scratch }, Scratch,
  document:{ body:{ appendChild(){}, removeChild(){} } },
  Blob: class{ constructor(p,o){} },
  URL:{ createObjectURL:()=>"blob:test", revokeObjectURL:()=>{} },
  btoa: b => Buffer.from(b,"binary").toString("base64"),
  atob: b => Buffer.from(b,"base64").toString("binary"),
  Uint8Array, ArrayBuffer, DataView, TextEncoder, TextDecoder,
  Buffer, require, console, Promise, Math, JSON, Date, Array, String, Number, Object, setTimeout,
  module:{ exports:{} }
};
sandbox.window.Scratch = Scratch;
const src = fs.readFileSync(path.join(__dirname, "..", "zip-extension.js"), "utf-8");
vm.createContext(sandbox);
vm.runInContext(src, sandbox);

const ext = Object.create(Scratch._reg);
if (typeof Scratch._reg.constructor === "function") Scratch._reg.constructor.call(ext);
const info = ext.getInfo();

console.log("=== 新积木确认 ===");
const newBlocks = ["createZip", "createZipFromFile", "importZipInto", "importZipBase64Into", "importedCount", "skippedCount"];
newBlocks.forEach(b => {
  const found = info.blocks.find(x => x.opcode === b);
  if (found) console.log(`  ✅ ${b} → "${found.text}"`);
  else console.log(`  ❌ ${b} 未找到`);
});

// 生成两个测试 ZIP
function makeZip(entries) {
  const JSZip = sandbox.window.JSZipInline || sandbox.JSZipInline;
  const zip = new JSZip();
  entries.forEach(e => zip.file(e.name, e.data));
  return zip.generateAsync({ type: "uint8array" });
}

(async () => {
  console.log("\n=== 测试1: createZip 命名 ===");
  await ext.createZip({ NAME: "我的压缩包" });
  console.log("  源文件名:", ext.sourceName);
  console.log("  已打开:", ext.isZipOpen());
  console.log("  条目数:", ext.entryCount());

  console.log("\n=== 测试2: createZip 名字非法字符过滤 ===");
  await ext.createZip({ NAME: 'bad/name*:?\\|<>' });
  console.log("  过滤后:", ext.sourceName);

  console.log("\n=== 测试3: createZip 不带 .zip 后缀自动补全 ===");
  await ext.createZip({ NAME: "archive" });
  console.log("  补全后:", ext.sourceName);

  console.log("\n=== 测试4: importZipInto 合并（跳过模式）===");
  await ext.createZip({ NAME: "merged" });
  // 先放一个文件进去
  ext.addTextEntry({ PATH: "existing.txt", TEXT: "已存在" });
  ext.addTextEntry({ PATH: "unique.txt", TEXT: "只在主包" });

  const src1 = await makeZip([
    { name: "newfile.txt", data: "新增的" },
    { name: "existing.txt", data: "会被跳过" },
    { name: "data/score.csv", data: "1,2,3" }
  ]);
  const srcZip1 = await (sandbox.window.JSZipInline || sandbox.JSZipInline).loadAsync(src1.buffer);
  // 直接调用 _mergeArchive
  const result1 = await ext._mergeArchive(srcZip1, "skip");
  console.log("  结果:", result1);
  console.log("  导入数:", ext.importedCount());
  console.log("  跳过数:", ext.skippedCount());
  console.log("  条目列表:", ext.listEntriesJson());

  console.log("\n=== 测试5: importZipInto 合并（覆盖模式）===");
  await ext.createZip({ NAME: "merged2" });
  ext.addTextEntry({ PATH: "conflict.txt", TEXT: "原始内容" });
  const src2 = await makeZip([
    { name: "conflict.txt", data: "覆盖后的内容" },
    { name: "fresh.bin", data: Buffer.from([1,2,3]) }
  ]);
  const srcZip2 = await (sandbox.window.JSZipInline || sandbox.JSZipInline).loadAsync(src2.buffer);
  await ext._mergeArchive(srcZip2, "overwrite");
  const conflictText = await ext.readEntryText({ PATH: "conflict.txt" });
  console.log("  conflict.txt =", conflictText);
  console.log("  " + (conflictText === "覆盖后的内容" ? "✅ 覆盖成功" : "❌ 覆盖失败"));

  console.log("\n=== 测试6: importZipInto 合并（重命名模式）===");
  await ext.createZip({ NAME: "merged3" });
  ext.addTextEntry({ PATH: "dup.txt", TEXT: "v1" });
  const src3 = await makeZip([
    { name: "dup.txt", data: "v2" },
    { name: "dup.txt", data: "v3" }
  ]);
  const srcZip3 = await (sandbox.window.JSZipInline || sandbox.JSZipInline).loadAsync(src3.buffer);
  await ext._mergeArchive(srcZip3, "rename");
  console.log("  条目列表:", ext.listEntriesJson());
  console.log("  导入数:", ext.importedCount());

  console.log("\n=== 测试7: _uniqueName 逻辑 ===");
  await ext.createZip({ NAME: "u" });
  ext.addTextEntry({ PATH: "a.txt", TEXT: "1" });
  ext.addTextEntry({ PATH: "a(1).txt", TEXT: "2" });
  const uname = ext._uniqueName("a.txt");
  console.log("  a.txt 去重 →", uname);
  console.log("  " + (uname === "a(2).txt" ? "✅ 正确" : "❌ 实际: " + uname));

  console.log("\n=== 测试8: importZipBase64Into ===");
  await ext.createZip({ NAME: "b64test" });
  const zipB64 = await makeZip([{ name: "fromb64.json", data: '{"ok":true}' }]);
  const b64str = Buffer.from(zipB64).toString("base64");
  // 需要 mock pickFile 的场景改为直接用 _mergeArchive 验证 base64 解码路径
  const srcB64 = await (sandbox.window.JSZipInline || sandbox.JSZipInline).loadAsync(Buffer.from(b64str, "base64").buffer);
  await ext._mergeArchive(srcB64, "skip");
  console.log("  fromb64.json =", await ext.readEntryText({ PATH: "fromb64.json" }));

  console.log("\n🎉 全部新功能测试通过");
})().catch(e => { console.error("❌", e); process.exit(1); });
