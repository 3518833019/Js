/**
 * 云列表同步扩展 v3 —— 私人服务器版
 * ============================================================
 * 核心机制：通过一个你自己的 WebSocket 中继服务器（私人服务器）让
 *           *不同浏览器 / 不同设备 / 跨网络* 的多个 TurboWarp 作品
 *           共享同一套云列表。服务器用「用户名 + 密码」做身份校验。
 *
 * ⚠️ 必须 Unsandboxed（非沙盒）运行 —— 需要 WebSocket 和运行时 API。
 *
 * 功能：
 *   ① 连接私人服务器（URL + 用户名 + 密码）
 *   ② 创建 / 删除列表，加入频道
 *   ③ 列表的「显示 / 隐藏」（本地隐藏 = 积木面板里看不到、查询结果返回空；
 *      广播隐藏 = 通知其他作品一起隐藏/显示）
 *   ④ 读写列表项、同步、事件帽块
 *
 * 随本文件附一份 server/ 目录下的 Node.js 中继服务器（run-server.js），
 * 先 `npm install ws` 再 `node run-server.js` 即可启动。
 */
(function (Scratch) {
    'use strict';

    if (!Scratch.extensions.unsandboxed) {
        throw new Error('云列表同步扩展必须在非沙盒（Unsandboxed）模式下运行');
    }

    // ────────────────────────────────────────────────────────────
    // 常量
    // ────────────────────────────────────────────────────────────
    var SEND_DEBOUNCE_MS = 30;
    var RECONNECT_MS = 3000;
    var PROTOCOL_VERSION = 1;

    // ────────────────────────────────────────────────────────────
    // 工具函数
    // ────────────────────────────────────────────────────────────
    function asString(v) {
        if (v === null || v === undefined) return '';
        if (typeof v === 'number' && !isFinite(v)) return '';
        return String(v);
    }
    function asIndex(v, listLen) {
        var n = Math.floor(Scratch.Cast.toNumber(v));
        if (!isFinite(n)) n = 1;
        if (n < 1) n = 1;
        if (listLen < 1) n = 1;
        if (n > listLen) n = listLen;
        return n;
    }
    function makeClientId() {
        return 'c-' + Math.random().toString(36).slice(2, 8) + Date.now().toString(36);
    }

    // ────────────────────────────────────────────────────────────
    // 核心扩展类
    // ────────────────────────────────────────────────────────────
    function CloudListSync() {
        this._clientId = makeClientId();

        // 连接参数（积木可改）
        this._url = 'ws://localhost:8080';
        this._username = '';
        this._password = '';

        // 列表数据：{ name -> { items:[...], visible:bool } }
        this._lists = Object.create(null);

        // 已在本作品运行时里登记的列表变量（用于隐藏时仍保留数据）
        this._registered = Object.create(null);

        // 连接状态
        this._ws = null;
        this._connected = false;
        this._loggedIn = false;
        this._status = '未连接';
        this._reconnectTimer = null;

        // 发送队列（断线时缓冲）
        this._queue = [];
        this._pending = Object.create(null);
        this._flushTimer = null;

        // 事件帽块
        this._lastList = '';
        this._lastIndex = 0;
        this._lastValue = '';
        this._lastType = '';
    }

    CloudListSync.prototype = {
        constructor: CloudListSync,

        // ── 运行时访问 ──
        _getRuntime: function () {
            try { return Scratch.vm && Scratch.vm.runtime; } catch (e) { return null; }
        },

        _findListVar: function (name) {
            var rt = this._getRuntime();
            if (!rt) return null;
            var targets = rt.targets || [];
            for (var i = 0; i < targets.length; i++) {
                var vars = (targets[i] && targets[i].variables) || Object.create(null);
                for (var id in vars) {
                    if (!Object.prototype.hasOwnProperty.call(vars, id)) continue;
                    var v = vars[id];
                    if (v && v[0] === name && Array.isArray(v[1])) return v;
                }
            }
            return null;
        },

        // 把内部数据同步到运行时变量
        _syncVar: function (name) {
            var meta = this._lists[name];
            if (!meta) return;
            var v = this._findListVar(name);
            if (v) v[1] = meta.items;
        },

        _createRuntimeListVar: function (name) {
            var rt = this._getRuntime();
            if (!rt) return false;
            var stage = rt.getTargetForStage ? rt.getTargetForStage() : null;
            if (!stage || !stage.variables) return false;
            if (this._findListVar(name)) { this._registered[name] = true; return true; }
            var id = 'list:' + Math.random().toString(36).slice(2, 10);
            var initial = (this._lists[name] && this._lists[name].items.slice()) || [];
            stage.variables[id] = [name, initial, false, 'list'];
            this._registered[name] = true;
            return true;
        },

        _deleteRuntimeListVar: function (name) {
            var rt = this._getRuntime();
            if (!rt) return false;
            var targets = rt.targets || [];
            var found = false;
            for (var i = 0; i < targets.length; i++) {
                var vars = (targets[i] && targets[i].variables) || Object.create(null);
                for (var id in vars) {
                    if (!Object.prototype.hasOwnProperty.call(vars, id)) continue;
                    var v = vars[id];
                    if (v && v[0] === name && Array.isArray(v[1])) {
                        delete vars[id];
                        found = true;
                    }
                }
            }
            return found;
        },

        _ensureList: function (name) {
            if (!this._lists[name]) {
                this._lists[name] = { items: [], visible: true };
            }
            return this._lists[name];
        },

        // ── 连接管理 ──
        _setStatus: function (s) { this._status = s; },

        _connect: function () {
            var self = this;
            if (this._ws) {
                try { this._ws.close(); } catch (e) {}
                this._ws = null;
            }
            var url = this._url;
            if (!/^wss?:\/\//i.test(url)) url = 'ws://' + url;
            this._setStatus('连接中…');

            var ws;
            try {
                ws = new WebSocket(url);
            } catch (e) {
                this._setStatus('连接失败：' + e.message);
                this._scheduleReconnect();
                return;
            }
            this._ws = ws;

            ws.onopen = function () {
                self._connected = true;
                self._setStatus('已连接，正在登录…');
                // 握手
                self._sendNow({
                    t: 'hello',
                    proto: PROTOCOL_VERSION,
                    clientId: self._clientId,
                    username: self._username,
                    password: self._password
                });
            };

            ws.onmessage = function (ev) {
                var msg;
                try { msg = JSON.parse(ev.data); } catch (e) { return; }
                self._handleMessage(msg);
            };

            ws.onerror = function () {
                self._setStatus('连接出错');
            };

            ws.onclose = function () {
                self._connected = false;
                self._loggedIn = false;
                self._setStatus('已断开，将重连…');
                self._scheduleReconnect();
            };
        },

        _scheduleReconnect: function () {
            if (this._reconnectTimer) return;
            var self = this;
            this._reconnectTimer = setTimeout(function () {
                self._reconnectTimer = null;
                self._connect();
            }, RECONNECT_MS);
        },

        _sendNow: function (obj) {
            if (!this._ws || this._ws.readyState !== 1 /* OPEN */) {
                this._queue.push(obj);
                return;
            }
            try { this._ws.send(JSON.stringify(obj)); } catch (e) {}
        },

        _send: function (obj) {
            obj.clientId = this._clientId;
            this._sendNow(obj);
        },

        _flushQueue: function () {
            while (this._queue.length) {
                var msg = this._queue.shift();
                try { this._ws.send(JSON.stringify(msg)); } catch (e) {}
            }
        },

        _scheduleFlush: function () {
            if (this._flushTimer) return;
            var self = this;
            this._flushTimer = setTimeout(function () {
                self._flushTimer = null;
                var names = Object.keys(self._pending);
                for (var i = 0; i < names.length; i++) {
                    self._send(self._pending[names[i]]);
                }
                self._pending = Object.create(null);
            }, SEND_DEBOUNCE_MS);
        },

        _queueChange: function (type, name, extra) {
            extra = extra || {};
            this._pending[name] = {
                t: 'listChange',
                type: type,
                name: name,
                index: 'index' in extra ? extra.index : undefined,
                value: 'value' in extra ? extra.value : undefined,
                items: 'items' in extra ? extra.items : undefined,
                length: 'length' in extra ? extra.length : undefined
            };
            this._scheduleFlush();
        },

        // ── 消息处理 ──
        _handleMessage: function (msg) {
            if (!msg || !msg.t) return;

            switch (msg.t) {
                case 'welcome': {
                    // 握手回执，拿到分配到的 clientId
                    if (msg.clientId) this._clientId = msg.clientId;
                    this._setStatus('已登录：' + (msg.user || this._username));
                    this._loggedIn = true;
                    this._flushQueue();
                    // 登录成功后自动把本地已有列表上报
                    this._reportExistingLists();
                    break;
                }
                case 'authFailed': {
                    this._setStatus('登录失败：' + (msg.reason || '用户名或密码错误'));
                    this._loggedIn = false;
                    if (this._ws) { try { this._ws.close(); } catch (e) {} }
                    break;
                }
                case 'listChange': {
                    if (msg.clientId === this._clientId) return;
                    this._applyRemote(msg);
                    break;
                }
                case 'listCreated': {
                    if (msg.clientId === this._clientId) return;
                    var arr = Array.isArray(msg.items) ? msg.items.slice() : [];
                    for (var i = 0; i < arr.length; i++) arr[i] = asString(arr[i]);
                    var meta = this._ensureList(msg.name);
                    meta.items = arr;
                    if (typeof msg.visible === 'boolean') meta.visible = msg.visible;
                    this._createRuntimeListVar(msg.name);
                    this._enqueueHat(msg.name, 0, '', 'create');
                    break;
                }
                case 'listDeleted': {
                    if (msg.clientId === this._clientId) return;
                    var name = msg.name;
                    delete this._lists[name];
                    this._deleteRuntimeListVar(name);
                    this._enqueueHat(name, 0, '', 'delete');
                    break;
                }
                case 'listVisibility': {
                    if (msg.clientId === this._clientId) return;
                    var m = this._ensureList(msg.name);
                    m.visible = !!msg.visible;
                    if (!m.visible) this._deleteRuntimeListVar(msg.name);
                    else this._createRuntimeListVar(msg.name);
                    this._enqueueHat(msg.name, 0, '', m.visible ? 'show' : 'hide');
                    break;
                }
                case 'snapshot': {
                    // 登录后服务器推来的全量快照
                    var lists = msg.lists || {};
                    for (var nm in lists) {
                        if (!Object.prototype.hasOwnProperty.call(lists, nm)) continue;
                        var entry = lists[nm];
                        var m2 = this._ensureList(nm);
                        var raw = Array.isArray(entry.items) ? entry.items : [];
                        m2.items = new Array(raw.length);
                        for (var k = 0; k < raw.length; k++) m2.items[k] = asString(raw[k]);
                        m2.visible = (entry.visible !== false);
                        if (m2.visible) this._createRuntimeListVar(nm);
                    }
                    this._setStatus('快照已同步（' + Object.keys(lists).length + ' 个列表）');
                    break;
                }
            }
        },

        _reportExistingLists: function () {
            var names = Object.keys(this._lists);
            for (var i = 0; i < names.length; i++) {
                var m = this._lists[names[i]];
                this._send({
                    t: 'listCreated',
                    name: names[i],
                    items: m.items.slice(),
                    visible: m.visible
                });
            }
        },

        _applyRemote: function (msg) {
            var name = msg.name;
            if (!name) return;
            var meta = this._ensureList(name);
            if (!meta.visible) return; // 已隐藏的列表不接受远程改动
            var list = meta.items;
            var oldVal = '';
            var idx = 0;

            switch (msg.type) {
                case 'set': {
                    idx = asIndex(msg.index, list.length);
                    oldVal = list[idx - 1];
                    list[idx - 1] = asString(msg.value);
                    break;
                }
                case 'insert': {
                    idx = asIndex(msg.index, list.length + 1);
                    list.splice(idx - 1, 0, asString(msg.value));
                    break;
                }
                case 'deleteItem': {
                    if (list.length === 0) return;
                    idx = asIndex(msg.index, list.length);
                    oldVal = list[idx - 1];
                    list.splice(idx - 1, 1);
                    break;
                }
                case 'replaceAll': {
                    var arr = Array.isArray(msg.items) ? msg.items.slice() : [];
                    for (var i = 0; i < arr.length; i++) arr[i] = asString(arr[i]);
                    meta.items = arr;
                    this._syncVar(name);
                    this._enqueueHat(name, 0, '', 'replaceAll');
                    return;
                }
                case 'length': {
                    var target = Math.max(0, Math.floor(Scratch.Cast.toNumber(msg.length)));
                    while (list.length < target) list.push('');
                    list.length = target;
                    this._syncVar(name);
                    this._enqueueHat(name, 0, '', 'length');
                    return;
                }
                default: return;
            }
            this._syncVar(name);
            this._enqueueHat(name, idx, oldVal, msg.type);
        },

        _enqueueHat: function (name, index, value, type) {
            this._lastList = name;
            this._lastIndex = index;
            this._lastValue = value;
            this._lastType = type;
            try {
                Scratch.vm.runtime.startHats('cloudlistsync_whenListUpdated', { LIST: name });
            } catch (e) {}
        },

        // ────────────────────────────────────────────────────────────
        // getInfo
        // ────────────────────────────────────────────────────────────
        getInfo: function () {
            var self = this;
            return {
                id: 'cloudlistsync',
                name: '云列表同步（私人服务器）',
                color1: '#00897b',
                color2: '#00695c',
                color3: '#004d40',
                blocks: [
                    // ── 连接 ──
                    {
                        opcode: 'setServer', blockType: Scratch.BlockType.COMMAND,
                        text: '设置服务器地址为 [URL]',
                        arguments: { URL: { type: Scratch.ArgumentType.STRING, defaultValue: 'ws://localhost:8080' } }
                    },
                    {
                        opcode: 'setCredentials', blockType: Scratch.BlockType.COMMAND,
                        text: '设置登录账号 [USER] 密码 [PASS]',
                        arguments: {
                            USER: { type: Scratch.ArgumentType.STRING, defaultValue: 'admin' },
                            PASS: { type: Scratch.ArgumentType.STRING, defaultValue: '123456' }
                        }
                    },
                    {
                        opcode: 'connect', blockType: Scratch.BlockType.COMMAND, text: '连接到私人服务器'
                    },
                    {
                        opcode: 'disconnect', blockType: Scratch.BlockType.COMMAND, text: '断开连接'
                    },
                    {
                        opcode: 'isConnected', blockType: Scratch.BlockType.BOOLEAN, text: '已连接？', disableMonitor: true
                    },
                    {
                        opcode: 'getStatus', blockType: Scratch.BlockType.REPORTER, text: '连接状态', disableMonitor: true
                    },

                    '---',

                    // ── 列表生命周期 ──
                    {
                        opcode: 'createList', blockType: Scratch.BlockType.COMMAND,
                        text: '创建云列表 [NAME]',
                        arguments: { NAME: { type: Scratch.ArgumentType.STRING, defaultValue: '新列表' } }
                    },
                    {
                        opcode: 'deleteList', blockType: Scratch.BlockType.COMMAND,
                        text: '删除云列表 [NAME]',
                        arguments: { NAME: { type: Scratch.ArgumentType.STRING, menu: 'listNames' } }
                    },
                    {
                        opcode: 'listExists', blockType: Scratch.BlockType.BOOLEAN,
                        text: '云列表 [NAME] 存在？',
                        arguments: { NAME: { type: Scratch.ArgumentType.STRING, menu: 'listNames' } }
                    },

                    '---',

                    // ── 显示 / 隐藏（你要的核心功能）──
                    {
                        opcode: 'showList', blockType: Scratch.BlockType.COMMAND,
                        text: '显示云列表 [NAME]',
                        arguments: { NAME: { type: Scratch.ArgumentType.STRING, menu: 'listNames' } }
                    },
                    {
                        opcode: 'hideList', blockType: Scratch.BlockType.COMMAND,
                        text: '隐藏云列表 [NAME]',
                        arguments: { NAME: { type: Scratch.ArgumentType.STRING, menu: 'listNames' } }
                    },
                    {
                        opcode: 'showListAll', blockType: Scratch.BlockType.COMMAND, text: '显示所有云列表'
                    },
                    {
                        opcode: 'hideListAll', blockType: Scratch.BlockType.COMMAND, text: '隐藏所有云列表'
                    },
                    {
                        opcode: 'isListVisible', blockType: Scratch.BlockType.BOOLEAN,
                        text: '云列表 [NAME] 是显示的？',
                        arguments: { NAME: { type: Scratch.ArgumentType.STRING, menu: 'listNames' } }
                    },
                    {
                        opcode: 'broadcastVisibility', blockType: Scratch.BlockType.COMMAND,
                        text: '向其他作品广播列表显隐状态',
                        hideFromPalette: false
                    },

                    '---',

                    // ── 列表读写（同步）──
                    {
                        opcode: 'setListItem', blockType: Scratch.BlockType.COMMAND,
                        text: '设置云列表 [LIST] 的第 [INDEX] 项为 [VALUE]',
                        arguments: {
                            LIST: { type: Scratch.ArgumentType.STRING, menu: 'listNames' },
                            INDEX: { type: Scratch.ArgumentType.NUMBER, defaultValue: 1 },
                            VALUE: { type: Scratch.ArgumentType.STRING, defaultValue: '' }
                        }
                    },
                    {
                        opcode: 'insertListItem', blockType: Scratch.BlockType.COMMAND,
                        text: '在云列表 [LIST] 的第 [INDEX] 项前插入 [VALUE]',
                        arguments: {
                            LIST: { type: Scratch.ArgumentType.STRING, menu: 'listNames' },
                            INDEX: { type: Scratch.ArgumentType.NUMBER, defaultValue: 1 },
                            VALUE: { type: Scratch.ArgumentType.STRING, defaultValue: '' }
                        }
                    },
                    {
                        opcode: 'deleteListItem', blockType: Scratch.BlockType.COMMAND,
                        text: '删除云列表 [LIST] 的第 [INDEX] 项',
                        arguments: {
                            LIST: { type: Scratch.ArgumentType.STRING, menu: 'listNames' },
                            INDEX: { type: Scratch.ArgumentType.NUMBER, defaultValue: 1 }
                        }
                    },
                    {
                        opcode: 'replaceAll', blockType: Scratch.BlockType.COMMAND,
                        text: '将云列表 [LIST] 的全部内容替换为 [ITEMS]（JSON 数组）',
                        arguments: {
                            LIST: { type: Scratch.ArgumentType.STRING, menu: 'listNames' },
                            ITEMS: { type: Scratch.ArgumentType.STRING, defaultValue: '["a","b","c"]' }
                        }
                    },
                    {
                        opcode: 'setListLength', blockType: Scratch.BlockType.COMMAND,
                        text: '把云列表 [LIST] 的长度设为 [LENGTH]',
                        arguments: {
                            LIST: { type: Scratch.ArgumentType.STRING, menu: 'listNames' },
                            LENGTH: { type: Scratch.ArgumentType.NUMBER, defaultValue: 0 }
                        }
                    },
                    {
                        opcode: 'appendItem', blockType: Scratch.BlockType.COMMAND,
                        text: '把 [VALUE] 加到云列表 [LIST] 末尾',
                        arguments: {
                            VALUE: { type: Scratch.ArgumentType.STRING, defaultValue: '' },
                            LIST: { type: Scratch.ArgumentType.STRING, menu: 'listNames' }
                        }
                    },

                    '---',

                    // ── 查询 ──
                    {
                        opcode: 'getListItem', blockType: Scratch.BlockType.REPORTER,
                        text: '云列表 [LIST] 的第 [INDEX] 项',
                        arguments: {
                            LIST: { type: Scratch.ArgumentType.STRING, menu: 'listNames' },
                            INDEX: { type: Scratch.ArgumentType.NUMBER, defaultValue: 1 }
                        },
                        disableMonitor: true
                    },
                    {
                        opcode: 'getListLength', blockType: Scratch.BlockType.REPORTER,
                        text: '云列表 [LIST] 的长度',
                        arguments: { LIST: { type: Scratch.ArgumentType.STRING, menu: 'listNames' } },
                        disableMonitor: true
                    },
                    {
                        opcode: 'getListAsJSON', blockType: Scratch.BlockType.REPORTER,
                        text: '云列表 [LIST] 的全部内容（JSON 数组）',
                        arguments: { LIST: { type: Scratch.ArgumentType.STRING, menu: 'listNames' } },
                        disableMonitor: true
                    },
                    {
                        opcode: 'allListNames', blockType: Scratch.BlockType.REPORTER,
                        text: '所有云列表名称（JSON 数组）',
                        disableMonitor: true
                    },

                    '---',

                    // ── 事件帽块 ──
                    {
                        blockType: Scratch.BlockType.EVENT, opcode: 'whenListUpdated',
                        text: '当云列表 [LIST] 收到更新',
                        isEdgeActivated: false,
                        arguments: { LIST: { type: Scratch.ArgumentType.STRING, menu: 'listNames' } }
                    },
                    {
                        opcode: 'updatedList', blockType: Scratch.BlockType.REPORTER, text: '被更新的云列表名', disableMonitor: true
                    },
                    {
                        opcode: 'updatedIndex', blockType: Scratch.BlockType.REPORTER, text: '更新的项位置', disableMonitor: true
                    },
                    {
                        opcode: 'updatedOldValue', blockType: Scratch.BlockType.REPORTER, text: '被替换/删除的旧值', disableMonitor: true
                    },
                    {
                        opcode: 'updatedChangeType', blockType: Scratch.BlockType.REPORTER, text: '更新类型', disableMonitor: true
                    }
                ],
                menus: {
                    listNames: {
                        acceptReporters: true,
                        items: function () { return self._collectListNames(); }
                    }
                }
            };
        },

        _collectListNames: function () {
            var names = [];
            var seen = Object.create(null);
            var rt = this._getRuntime();
            if (rt) {
                var targets = rt.targets || [];
                for (var i = 0; i < targets.length; i++) {
                    var vars = (targets[i] && targets[i].variables) || Object.create(null);
                    for (var id in vars) {
                        if (!Object.prototype.hasOwnProperty.call(vars, id)) continue;
                        var v = vars[id];
                        if (v && Array.isArray(v[1]) && !seen[v[0]]) {
                            seen[v[0]] = true;
                            names.push(v[0]);
                        }
                    }
                }
            }
            var known = Object.keys(this._lists);
            for (var j = 0; j < known.length; j++) {
                if (!seen[known[j]]) { seen[known[j]] = true; names.push(known[j]); }
            }
            if (names.length === 0) names.push('云列表1');
            return names;
        },

        // ────────────────────────────────────────────────────────────
        // 积木实现 —— 连接
        // ────────────────────────────────────────────────────────────
        setServer: function (args) {
            var url = Scratch.Cast.toString(args.URL) || 'ws://localhost:8080';
            this._url = url;
        },
        setCredentials: function (args) {
            this._username = Scratch.Cast.toString(args.USER);
            this._password = Scratch.Cast.toString(args.PASS);
        },
        connect: function () { this._connect(); },
        disconnect: function () {
            this._loggedIn = false;
            if (this._reconnectTimer) { clearTimeout(this._reconnectTimer); this._reconnectTimer = null; }
            if (this._ws) { try { this._ws.close(); } catch (e) {} this._ws = null; }
            this._setStatus('已手动断开');
        },
        isConnected: function () { return this._connected && this._loggedIn; },
        getStatus: function () { return this._status; },

        // 列表生命周期
        createList: function (args) {
            var name = Scratch.Cast.toString(args.NAME);
            if (!name) return;
            var meta = this._ensureList(name);
            meta.visible = true;
            this._createRuntimeListVar(name);
            this._send({ t: 'listCreated', name: name, items: meta.items.slice(), visible: true });
            this._enqueueHat(name, 0, '', 'create');
        },
        deleteList: function (args) {
            var name = Scratch.Cast.toString(args.NAME);
            if (!name) return;
            delete this._lists[name];
            this._deleteRuntimeListVar(name);
            this._send({ t: 'listDeleted', name: name });
            this._enqueueHat(name, 0, '', 'delete');
        },
        listExists: function (args) {
            var name = Scratch.Cast.toString(args.NAME);
            return this._lists[name] !== undefined || this._findListVar(name) !== null;
        },

        // 显示 / 隐藏
        showList: function (args) {
            var name = Scratch.Cast.toString(args.NAME);
            var meta = this._ensureList(name);
            meta.visible = true;
            this._createRuntimeListVar(name);
            this._send({ t: 'listVisibility', name: name, visible: true });
            this._enqueueHat(name, 0, '', 'show');
        },
        hideList: function (args) {
            var name = Scratch.Cast.toString(args.NAME);
            var meta = this._ensureList(name);
            meta.visible = false;
            this._deleteRuntimeListVar(name); // 隐藏 = 从运行时变量面板移除
            this._send({ t: 'listVisibility', name: name, visible: false });
            this._enqueueHat(name, 0, '', 'hide');
        },
        showListAll: function () {
            var names = Object.keys(this._lists);
            for (var i = 0; i < names.length; i++) {
                this._lists[names[i]].visible = true;
                this._createRuntimeListVar(names[i]);
            }
        },
        hideListAll: function () {
            var names = Object.keys(this._lists);
            for (var i = 0; i < names.length; i++) {
                this._lists[names[i]].visible = false;
                this._deleteRuntimeListVar(names[i]);
            }
        },
        isListVisible: function (args) {
            var name = Scratch.Cast.toString(args.NAME);
            var meta = this._lists[name];
            return meta ? meta.visible : false;
        },
        broadcastVisibility: function () {
            var names = Object.keys(this._lists);
            for (var i = 0; i < names.length; i++) {
                var m = this._lists[names[i]];
                this._send({ t: 'listVisibility', name: names[i], visible: m.visible });
            }
        },

        // 列表写操作
        setListItem: function (args) {
            var name = Scratch.Cast.toString(args.LIST);
            var meta = this._ensureList(name);
            if (!meta.visible) return;
            var list = meta.items;
            var idx = asIndex(args.INDEX, list.length);
            var value = asString(args.VALUE);
            list[idx - 1] = value;
            this._syncVar(name);
            this._queueChange('set', name, { index: idx, value: value });
        },
        insertListItem: function (args) {
            var name = Scratch.Cast.toString(args.LIST);
            var meta = this._ensureList(name);
            if (!meta.visible) return;
            var list = meta.items;
            var idx = asIndex(args.INDEX, list.length + 1);
            var value = asString(args.VALUE);
            list.splice(idx - 1, 0, value);
            this._syncVar(name);
            this._queueChange('insert', name, { index: idx, value: value });
        },
        deleteListItem: function (args) {
            var name = Scratch.Cast.toString(args.LIST);
            var meta = this._ensureList(name);
            if (!meta.visible) return;
            var list = meta.items;
            if (list.length === 0) return;
            var idx = asIndex(args.INDEX, list.length);
            var oldVal = list[idx - 1];
            list.splice(idx - 1, 1);
            this._syncVar(name);
            this._queueChange('deleteItem', name, { index: idx });
            this._enqueueHat(name, idx, oldVal, 'deleteItem');
        },
        replaceAll: function (args) {
            var name = Scratch.Cast.toString(args.LIST);
            var meta = this._ensureList(name);
            if (!meta.visible) return;
            var raw = Scratch.Cast.toString(args.ITEMS);
            var arr = [];
            try {
                var parsed = JSON.parse(raw);
                arr = Array.isArray(parsed) ? parsed : [parsed];
            } catch (e) { arr = [raw]; }
            for (var i = 0; i < arr.length; i++) arr[i] = asString(arr[i]);
            meta.items = arr;
            this._syncVar(name);
            this._queueChange('replaceAll', name, { items: arr });
        },
        setListLength: function (args) {
            var name = Scratch.Cast.toString(args.LIST);
            var meta = this._ensureList(name);
            if (!meta.visible) return;
            var list = meta.items;
            var target = Math.max(0, Math.floor(Scratch.Cast.toNumber(args.LENGTH)));
            while (list.length < target) list.push('');
            list.length = target;
            this._syncVar(name);
            this._queueChange('length', name, { length: target });
        },
        appendItem: function (args) {
            var name = Scratch.Cast.toString(args.LIST);
            var meta = this._ensureList(name);
            if (!meta.visible) return;
            var value = asString(args.VALUE);
            meta.items.push(value);
            this._syncVar(name);
            this._queueChange('insert', name, { index: meta.items.length, value: value });
        },

        // 查询
        getListItem: function (args) {
            var name = Scratch.Cast.toString(args.LIST);
            var meta = this._lists[name];
            if (!meta || !meta.visible) return ''; // 隐藏时返回空
            var list = meta.items;
            if (list.length === 0) return '';
            var idx = asIndex(args.INDEX, list.length);
            return asString(list[idx - 1]);
        },
        getListLength: function (args) {
            var name = Scratch.Cast.toString(args.LIST);
            var meta = this._lists[name];
            return (meta && meta.visible) ? meta.items.length : 0;
        },
        getListAsJSON: function (args) {
            var name = Scratch.Cast.toString(args.LIST);
            var meta = this._lists[name];
            if (!meta || !meta.visible) return '[]';
            return JSON.stringify(meta.items);
        },
        allListNames: function () {
            var names = this._collectListNames();
            return JSON.stringify(names);
        },

        // 帽块
        whenListUpdated: function () { /* no-op */ },
        updatedList: function () { return this._lastList; },
        updatedIndex: function () { return this._lastIndex; },
        updatedOldValue: function () { return this._lastValue; },
        updatedChangeType: function () { return this._lastType; }
    };

    Scratch.extensions.register(new CloudListSync());
})(Scratch);
