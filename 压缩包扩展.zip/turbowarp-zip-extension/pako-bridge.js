// ===================================================================
//  pako 桥接（可选，MIT 许可证 —— https://github.com/nodeca/pako）
//  作用：让「内联 JSZipInline」在浏览器端也能解压任意 DEFLATE 块。
//
//  用法（在加载 zip-extension.js 之前先执行）：
//    if (window.pako) PakoBridge.install(window.pako);
//
//  实现：把 pako.inflateRaw 包装成与内联 inflateRaw 相同签名的函数，
//  并替换 JSZipInline 内部引用。若 pako 不可用则无副作用。
// ===================================================================
(function (global) {
  function install(pako) {
    if (!pako || typeof pako.inflateRaw !== "function") return false;
    // 延迟到 JSZipInline 已定义后打补丁
    function patch() {
      if (!global.JSZipInline || !global.JSZipInline.__patch) return false;
      return global.JSZipInline.__patch(function (input) {
        try {
          var buf = pako.inflateRaw(new Uint8Array(input));
          return buf instanceof Uint8Array ? buf : new Uint8Array(buf);
        } catch (e) {
          throw e; // 交给调用方
        }
      });
    }
    if (!patch()) {
      // JSZipInline 尚未加载，排队
      var prev = global.addEventListener;
      // 简单轮询（TurboWarp 加载顺序可控，通常同步）
      var timer = setInterval(function () {
        if (patch()) clearInterval(timer);
      }, 10);
      setTimeout(function () { clearInterval(timer); }, 3000);
    }
    return true;
  }
  global.PakoBridge = { install: install };
})(typeof window !== "undefined" ? window : global);
