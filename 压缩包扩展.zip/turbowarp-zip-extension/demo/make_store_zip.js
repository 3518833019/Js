// 用 Node zlib 生成「仅 Store」的合法 ZIP（避免动态 Huffman 兼容性风险），用于验证扩展能读
const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

const OUT = path.join(__dirname, "sample_store.zip");

const CRC_TABLE = new Uint32Array(256);
(function () {
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    CRC_TABLE[i] = c >>> 0;
  }
})();
function crc32(buf) { let c = 0xFFFFFFFF; for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
function dos(d) {
  d = d || new Date();
  const y = d.getUTCFullYear() - 1980, mon = d.getUTCMonth() + 1, day = d.getUTCDate();
  const h = d.getUTCHours(), m = d.getUTCMinutes(), s = Math.floor(d.getUTCSeconds() / 2);
  return [((h & 31) << 11) | ((m & 63) << 5) | (s & 31), ((y & 127) << 9) | ((mon & 15) << 5) | (day & 31)];
}

const files = [
  { name: "readme.txt",      body: "Hello Store ZIP!\n中文行\nEmoji 📦\n" },
  { name: "data/config.json", body: '{"ok":true}\n' },
  { name: "assets/",         body: null },
  { name: "assets/note.txt", body: "nested" },
  { name: "bin/raw.bin",     body: Buffer.from([0x00, 0x01, 0xFF, 0x80, 0x7F]) }
];

const local = [], central = [];
let offset = 0;
files.forEach(f => {
  const nameBytes = Buffer.from(f.name, "utf-8");
  const raw = f.body === null ? Buffer.alloc(0) : (Buffer.isBuffer(f.body) ? f.body : Buffer.from(f.body, "utf-8"));
  const comp = raw; // Store
  const crc = crc32(raw);
  const [mt, md] = dos();
  const flag = 0x0800; // UTF-8 标志

  const h = Buffer.alloc(30);
  h.writeUInt32LE(0x04034B50, 0);
  h.writeUInt16LE(20, 4); h.writeUInt16LE(flag, 6); h.writeUInt16LE(0, 8); // method=Store
  h.writeUInt16LE(mt, 10); h.writeUInt16LE(md, 12);
  h.writeUInt32LE(crc, 14);
  h.writeUInt32LE(comp.length, 18); h.writeUInt32LE(raw.length, 22);
  h.writeUInt16LE(nameBytes.length, 26); h.writeUInt16LE(0, 28);

  local.push(h, nameBytes, comp);

  const c = Buffer.alloc(46);
  c.writeUInt32LE(0x02014B50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6);
  c.writeUInt16LE(flag, 8); c.writeUInt16LE(0, 10);
  c.writeUInt16LE(mt, 12); c.writeUInt16LE(md, 14);
  c.writeUInt32LE(crc, 16); c.writeUInt32LE(comp.length, 20); c.writeUInt32LE(raw.length, 24);
  c.writeUInt16LE(nameBytes.length, 28); c.writeUInt16LE(0, 30); c.writeUInt16LE(0, 32);
  c.writeUInt16LE(0, 34); c.writeUInt32LE(f.body === null ? 0x10 : 0, 38);
  c.writeUInt32LE(offset, 42);
  central.push(c, nameBytes);

  offset += h.length + nameBytes.length + comp.length;
});
const cen = Buffer.concat(central);
const eocd = Buffer.alloc(22);
eocd.writeUInt32LE(0x06054B50, 0); eocd.writeUInt16LE(0, 4); eocd.writeUInt16LE(0, 6);
eocd.writeUInt16LE(files.length, 8); eocd.writeUInt16LE(files.length, 10);
eocd.writeUInt32LE(cen.length, 12); eocd.writeUInt32LE(offset, 16);
fs.writeFileSync(OUT, Buffer.concat([...local, cen, eocd]));
console.log("✅", OUT, fs.statSync(OUT).size, "bytes");
