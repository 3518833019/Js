// 用「真实 ZIP（含 Deflate 块）」验证扩展的解析能力
// 结论：若系统有 pako，导出端走 Deflate；导入端用内联 inflate。
//       若内联 inflate 对动态 Huffman 支持不完整，导入 Deflate 块会失败——
//       这是已知的工程取舍（见 README）。本测试用于明确边界。
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const zlib = require("zlib");

const Scratch = {
  extensions: { register(inst){ Scratch._reg = inst; }, unsandboxed: true, _reg: null },
  ArgumentType: { STRING: "string", NUMBER: "number", BOOLEAN: "boolean" },
  BlockType: { COMMAND: "command", REPORTER: "reporter", BOOLEAN: "boolean", HAT: "hat" }
};
const sandbox = {
  window:{ Scratch }, Scratch,
  document:{ body:{ appendChild(){}, removeChild(){} } },
  Blob: class{ constructor(p,o){} },
  URL:{ createObjectURL:()=>"blob:test", revokeObjectURL:()=>{} },
  btoa: b => Buffer.from(b,"binary").toString("base64"),
  atob: b => Buffer.from(b,"base64").toString("binary"),
  Uint8Array, ArrayBuffer, DataView, TextEncoder, TextDecoder,
  Buffer, require, console, Promise, Math, JSON, Date, Array, String, Number, Object, setTimeout,
  module:{ exports:{} }
};
sandbox.window.Scratch = Scratch;
const src = fs.readFileSync(path.join(__dirname, "..", "zip-extension.js"), "utf-8");
vm.createContext(sandbox);
vm.runInContext(src, sandbox);

const ext = Object.create(Scratch._reg);
if (typeof Scratch._reg.constructor === "function") Scratch._reg.constructor.call(ext);
ext.getInfo();

// 用系统 zlib 生成一个「Deflate」ZIP
function makeDeflateZip() {
  const tmp = path.join(__dirname, "_tmp");
  fs.mkdirSync(tmp, { recursive: true });
  fs.writeFileSync(path.join(tmp, "hello.txt"), "deflate 压缩的中文 🎉");
  fs.writeFileSync(path.join(tmp, "bin.bin"), Buffer.from([9,8,7,6,5]));
  const out = path.join(__dirname, "_deflate.zip");
  const { execSync } = require("child_process");
  execSync(`cd ${tmp} && zip -q -r ${out} . -x "*.DS_Store"`, { stdio: "pipe" });
  const buf = fs.readFileSync(out);
  fs.unlinkSync(out); fs.rmdirSync(tmp, { recursive: true });
  return buf;
}

(async () => {
  const zip = makeDeflateZip();
  console.log("测试 ZIP 大小:", zip.length, "字节 (含 Deflate 块)");

  // 情况 A：直接走内联 JSZipInline 解析
  console.log("\n[A] 内联解析器直接 loadAsync:");
  try {
    const JSZipInline = sandbox.window.JSZipInline || sandbox.JSZipInline;
    const arc = await JSZipInline.loadAsync(zip.buffer);
    const names = [];
    arc.forEach(n => names.push(n));
    console.log("  条目:", names.join(", "));
    console.log("  hello.txt =", new TextDecoder().decode(await arc.file("hello.txt").async("uint8array")));
    console.log("  ✅ 内联 inflate 可解此 ZIP");
  } catch (e) {
    console.log("  ❌ 内联 inflate 失败:", e.message);
    console.log("  → 说明：内联 inflate 对动态 Huffman 表的解码存在边界问题；");
    console.log("    生产环境导入 Deflate 块建议 require('zlib') 或用 pako。");
  }

  // 情况 B：走适配器（Desktop 有 zlib，可解）
  console.log("\n[B] 适配器 ZIP.read (Desktop 会探测到 Node zlib):");
  try {
    await ext.loadZipFromBase64({ DATA: Buffer.from(zip).toString("base64") });
    console.log("  条目数:", ext.entryCount());
    console.log("  hello.txt =", await ext.readEntryText({ PATH: "hello.txt" }));
    console.log("  bin.bin (Base64) =", await ext.readEntryBase64({ PATH: "bin.bin" }));
    console.log("  ✅ 通过 Node zlib 可正常解析 Deflate");
  } catch (e) {
    console.log("  ❌", e.message);
  }

  // 情况 C：Store ZIP（始终安全）
  console.log("\n[C] Store ZIP (sample_store.zip):");
  const store = fs.readFileSync(path.join(__dirname, "sample_store.zip"));
  await ext.loadZipFromBase64({ DATA: Buffer.from(store).toString("base64") });
  console.log("  条目数:", ext.entryCount());
  console.log("  readme.txt =", JSON.stringify(await ext.readEntryText({ PATH: "readme.txt" })));
  console.log("  assets/ 是目录:", ext.entryIsDirectory({ PATH: "assets/" }));
  console.log("  bin/raw.bin =", await ext.readEntryBase64({ PATH: "bin/raw.bin" }));
})().catch(e => { console.error(e); process.exit(1); });
