// 端到端测试：require 扩展源码，模拟 Scratch，跑完整 CRUD
const fs = require("fs");
const path = require("path");
const vm = require("vm");

// ---- Scratch 桩 ----
const Scratch = {
  extensions: {
    register: function (inst) { Scratch._reg = inst; },
    unsandboxed: true,
    _reg: null
  },
  ArgumentType: { STRING: "string", NUMBER: "number", BOOLEAN: "boolean" },
  BlockType: { COMMAND: "command", REPORTER: "reporter", BOOLEAN: "boolean", HAT: "hat" }
};

const sandbox = {
  window: { Scratch: Scratch },
  Scratch: Scratch,
  document: { body: { appendChild() {}, removeChild() {} } },
  Blob: class { constructor(p,o){this.p=p;this.o=o;} },
  URL: { createObjectURL: () => "blob:test", revokeObjectURL: () => {} },
  btoa: (b) => Buffer.from(b,"binary").toString("base64"),
  atob: (b) => Buffer.from(b,"base64").toString("binary"),
  Uint8Array, ArrayBuffer, DataView, TextEncoder, TextDecoder,
  Buffer, require, console, Promise, Math, JSON, Date, Array, setTimeout, Object, String, Number,
  module: { exports: {} }
};
sandbox.window.Scratch = Scratch;

const src = fs.readFileSync(path.join(__dirname, "..", "zip-extension.js"), "utf-8");
vm.createContext(sandbox);
vm.runInContext(src, sandbox);

// Scratch._reg 是原型对象（PlainObjectWithGetInfo），直接 Object.create 更安全
const ext = Object.create(Scratch._reg);
if (typeof Scratch._reg.constructor === "function") {
  Scratch._reg.constructor.call(ext);
}
const info = ext.getInfo();
console.log("扩展 ID:", info.id, "| 名称:", info.name, "| 积木数:", info.blocks.length);
console.log("积木 opcode 清单:");
info.blocks.forEach(b => console.log("  •", b.opcode, "[" + b.blockType + "]", b.text));

const sample = fs.readFileSync(path.join(__dirname, "sample.zip"));

(async () => {
  // 导入
  await ext.loadZipFromBase64({ DATA: Buffer.from(sample).toString("base64") });
  console.log("\n[导入] 已打开:", ext.isZipOpen(), "| 引擎:", ext.zipBackend(), "| 可使用 fs:", ext.canUseFilesystem());
  console.log("[读取] 条目数:", ext.entryCount());
  console.log("[读取] 条目列表:", ext.listEntriesJson());
  console.log("[读取] readme.txt =", JSON.stringify((await ext.readEntryText({ PATH: "readme.txt" })).slice(0, 30)));
  console.log("[读取] bin/zero.bin (Base64) =", await ext.readEntryBase64({ PATH: "bin/zero.bin" }));
  console.log("[判断] assets/ 是目录:", ext.entryIsDirectory({ PATH: "assets/" }));
  console.log("[判断] assets/note.txt 存在:", ext.entryExists({ PATH: "assets/note.txt" }));
  console.log("[安全] ../../etc/passwd 不存在:", !ext.entryExists({ PATH: "../../../etc/passwd" }));

  // 写入
  ext.addTextEntry({ PATH: "added.txt", TEXT: "由扩展写入" });
  ext.addBinaryEntry({ PATH: "img/favicon.ico", DATA: Buffer.from("fake-ico-bytes").toString("base64") });
  ext.addTextEntry({ PATH: "readme.txt", TEXT: "已被覆盖为新内容" }); // 覆盖
  await ext.renameEntry({ OLD: "added.txt", NEW: "renamed.txt" });
  ext.removeEntry({ PATH: "data/empty.txt" });
  console.log("\n[写入] 修改后条目数:", ext.entryCount());
  console.log("[读取] 覆盖后的 readme.txt =", JSON.stringify(await ext.readEntryText({ PATH: "readme.txt" })));
  console.log("[判断] renamed.txt 存在:", ext.entryExists({ PATH: "renamed.txt" }));

  // 导出
  const exported = await ext.exportZipBase64();
  const outBuf = Buffer.from(exported, "base64");
  const outPath = path.join(__dirname, "_roundtrip.zip");
  fs.writeFileSync(outPath, outBuf);
  console.log("\n[导出] 生成 _roundtrip.zip:", outBuf.length, "字节");

  const { execSync } = require("child_process");
  console.log("\n===== 系统 unzip -l 验证 =====");
  console.log(execSync("unzip -l " + outPath, { encoding: "utf-8" }));
  console.log("===== unzip -p readme.txt =====");
  console.log(execSync("unzip -p " + outPath + " readme.txt", { encoding: "utf-8" }));
  console.log("===== unzip -p renamed.txt =====");
  console.log(execSync("unzip -p " + outPath + " renamed.txt", { encoding: "utf-8" }));

  // 路径遍历防护
  console.log("===== 安全回归 =====");
  ext.addTextEntry({ PATH: "../../../evil.txt", TEXT: "x" });
  ext.addTextEntry({ PATH: "/etc/passwd", TEXT: "x" });
  ext.addTextEntry({ PATH: "a/../../b.txt", TEXT: "x" });
  console.log("拒绝 ../ :", !ext.entryExists({ PATH: "evil.txt" }) && !ext.entryExists({ PATH: "b.txt" }));
  console.log("拒绝 / 开头:", !ext.entryExists({ PATH: "etc/passwd" }));
  console.log("最后错误码:", JSON.stringify(ext.lastZipError()));

  // 大文件上限
  ext.setZipLimit({ ARCHIVE: 1024, ENTRY: 512 });
  await ext.loadZipFromBase64({ DATA: Buffer.from(sample).toString("base64") });
  console.log("上限生效（大包拒绝）:", ext.lastZipError() === "ERR_ARCHIVE_TOO_LARGE");

  fs.unlinkSync(outPath);
  console.log("\n🎉 端到端测试全部通过");
})().catch(e => { console.error("❌ 失败:", e); process.exit(1); });
