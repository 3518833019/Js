// 导出端 Deflate 往返测试：扩展生成 ZIP → 系统 unzip 解压 → 内容一致
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const { execSync } = require("child_process");

const Scratch = {
  extensions: { register(inst){ Scratch._reg = inst; }, unsandboxed: true, _reg: null },
  ArgumentType: { STRING: "string", NUMBER: "number", BOOLEAN: "boolean" },
  BlockType: { COMMAND: "command", REPORTER: "reporter", BOOLEAN: "boolean", HAT: "hat" }
};
const sandbox = {
  window:{ Scratch }, Scratch,
  document:{ body:{ appendChild(){}, removeChild(){} } },
  Blob: class{ constructor(p,o){} },
  URL:{ createObjectURL:()=>"blob:test", revokeObjectURL:()=>{} },
  btoa: b => Buffer.from(b,"binary").toString("base64"),
  atob: b => Buffer.from(b,"base64").toString("binary"),
  Uint8Array, ArrayBuffer, DataView, TextEncoder, TextDecoder,
  Buffer, require, console, Promise, Math, JSON, Date, Array, String, Number, Object, setTimeout,
  module:{ exports:{} }
};
sandbox.window.Scratch = Scratch;
const src = fs.readFileSync(path.join(__dirname, "..", "zip-extension.js"), "utf-8");
vm.createContext(sandbox);
vm.runInContext(src, sandbox);

const ext = Object.create(Scratch._reg);
if (typeof Scratch._reg.constructor === "function") Scratch._reg.constructor.call(ext);
ext.getInfo();

(async () => {
  // 新建空 ZIP
  await ext.createZip();
  ext.addTextEntry({ PATH: "greeting.txt", TEXT: "Hello Deflate! 你好" });
  ext.addTextEntry({ PATH: "data/nums.csv", TEXT: "1,2,3\n4,5,6\n" });
  ext.addBinaryEntry({ PATH: "img/pixel.png", DATA: Buffer.from([137,80,78,71,0,0,0,0]).toString("base64") });
  ext.addTextEntry({ PATH: "empty/", TEXT: "" }); // 目录

  const b64 = await ext.exportZipBase64();
  const zipBuf = Buffer.from(b64, "base64");
  const zpath = path.join(__dirname, "_rt.zip");
  fs.writeFileSync(zpath, zipBuf);
  console.log("生成 ZIP:", zipBuf.length, "字节");

  console.log("\n===== unzip -l =====");
  console.log(execSync("unzip -l " + zpath, { encoding: "utf-8" }));

  console.log("===== unzip -p greeting.txt =====");
  console.log(JSON.stringify(execSync("unzip -p " + zpath + " greeting.txt", { encoding: "utf-8" })));

  console.log("===== unzip -p data/nums.csv =====");
  console.log(execSync("unzip -p " + zpath + " data/nums.csv", { encoding: "utf-8" }));

  console.log("===== unzip -p img/pixel.png (hex) =====");
  console.log(execSync("unzip -p " + zpath + " img/pixel.png | xxd | head -3", { encoding: "utf-8" }));

  // 验证条目列表
  console.log("\n[扩展自检] 条目列表:", ext.listEntriesJson());

  fs.unlinkSync(zpath);
  console.log("\n🎉 Deflate 往返一致");
})().catch(e => { console.error("❌", e); process.exit(1); });
