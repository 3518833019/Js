// 模糊测试 pako-inflate-lite：与 Node zlib 做 oracle 比对
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const zlib = require("zlib");

const src = fs.readFileSync(path.join(__dirname, "..", "pako-inflate-lite.js"), "utf-8");
const sandbox = { window:{}, Uint8Array, ArrayBuffer, DataView, console, Math, module:{exports:{}} };
vm.createContext(sandbox);
vm.runInContext(src + "\nmodule.exports = pako;", sandbox);
const pako = sandbox.module.exports;

const cases = [];
cases.push("The quick brown fox");
cases.push("你好，世界！emoji 🚀🌍");
cases.push("aaaaaaaaaaaaaaaaa");
cases.push("abracadabra ".repeat(60));
cases.push(new Uint8Array([0,1,2,254,255,128]));
cases.push(new Uint8Array(300).fill(97));
cases.push(new Uint8Array(0));
const rnd = new Uint8Array(2048);
for (let i = 0; i < rnd.length; i++) rnd[i] = Math.floor(Math.random()*256);
cases.push(rnd);

let pass = 0, fail = 0;
for (let i = 0; i < cases.length; i++) {
  const raw = Buffer.isBuffer(cases[i]) ? cases[i] : Buffer.from(cases[i], "utf-8");
  for (let level = 0; level <= 9; level++) {
    const comp = zlib.deflateRawSync(raw, { level });
    try {
      const got = pako.inflateRaw(new Uint8Array(comp));
      if (got.length === raw.length && Buffer.from(got).equals(raw)) pass++;
      else { fail++; console.error(`❌ case ${i} level ${level} 长度 ${raw.length} -> ${got.length}`); }
    } catch (e) {
      fail++;
      console.error(`❌ case ${i} level ${level} 抛错:`, e.message.slice(0, 60));
    }
  }
}
console.log(`\npako-lite inflate 模糊测试：通过 ${pass} / 失败 ${fail}  (${cases.length * 10} 组)`);
process.exit(fail > 0 ? 1 : 0);
