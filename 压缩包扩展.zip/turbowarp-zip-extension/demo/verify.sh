#!/usr/bin/env bash
# 一键验证扩展（Node 桩测试，无需 TurboWarp 界面）
set -e
cd "$(dirname "$0")"
echo "== 1/4 语法检查 =="
node --check ../zip-extension.js && echo "OK"
echo "== 2/4 生成 Store ZIP 样本 =="
node make_store_zip.js
echo "== 3/4 端到端 CRUD =="
node test_e2e.js
echo "== 4/4 Deflate 往返 + 系统 unzip 校验 =="
node test_roundtrip_deflate.js
echo "== 5/5 inflate 非压缩块模糊测试 =="
node fuzz_store.js
echo ""
echo "🎉 全部通过"
