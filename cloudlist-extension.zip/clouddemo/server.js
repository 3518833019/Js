// 极简 Scratch 云变量协议服务器 —— 支持字符串值
// 协议：https://github.com/TurboWarp/cloud-server/blob/master/doc/protocol.md
//
// 握手：客户端 → {"method":"handshake","project_id":"房间名","user":"用户名"}
// 写入：任一端 → {"method":"set","name":"☁ 变量名","value":"值"}
// 服务器把同房间的 set 广播给所有其他连接端（含初次连入时的当前值）。
//
// 特点：
//   1. 允许字符串值（官方 cloud-server 只允许数字，这正是"连不上/存不进去"的常见原因）
//   2. 列表以 JSON 字符串存储在一个云变量里，扩展端负责序列化/反序列化
//   3. 纯内存存储，房间空了就清空；适合开发和小规模联调
//   4. 默认 0.0.0.0:8090，wss 需自己在前面套 nginx/caddy

const http = require('http');
const fs = require('fs');
const path = require('path');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 8090;
const HOST = process.env.HOST || '0.0.0.0';
const MAX_VALUE = Number(process.env.MAX_VALUE_LENGTH) || 100000; // 留足 JSON 列表空间

// project_id -> Map<varName, value>
const rooms = new Map();
// ws -> { project_id, user }
const clients = new Map();

function getRoom(projectId) {
  let room = rooms.get(projectId);
  if (!room) { room = new Map(); rooms.set(projectId, room); }
  return room;
}

function broadcast(projectId, message, except) {
  const text = JSON.stringify(message);
  for (const [ws, meta] of clients.entries()) {
    if (ws === except) continue;
    if (meta.project_id !== projectId) continue;
    if (ws.readyState === ws.OPEN) ws.send(text);
  }
}

const server = http.createServer((req, res) => {
  // 一个极简的调试页：查看房间列表和当前值
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname === '/') {
    let html = '<h1>Cloud List Server</h1><p>在线房间：</p><ul>';
    for (const [pid, vars] of rooms.entries()) {
      html += `<li><b>${pid}</b>（${[...clients.values()].filter(c => c.project_id === pid).length} 人在线）<ul>`;
      for (const [k, v] of vars.entries()) {
        const disp = String(v).length > 120 ? String(v).slice(0, 120) + '…' : v;
        html += `<li><code>${k}</code> = ${disp}</code></li>`;
      }
      html += '</ul></li>';
    }
    html += '</ul><p>扩展端点：ws://你的地址:' + PORT + '/</p>';
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
    return;
  }
  res.writeHead(404); res.end();
});

const wss = new WebSocketServer({ server, path: '/' });

wss.on('connection', (ws) => {
  let meta = { project_id: null, user: null };
  clients.set(ws, meta);

  ws.on('message', (raw) => {
    const text = raw.toString('utf8');
    // 服务器可能一次发多条，用换行分隔
    const parts = text.split('\n');
    for (const chunk of parts) {
      const msg = chunk.trim();
      if (!msg) continue;
      let obj;
      try { obj = JSON.parse(msg); } catch (e) { continue; }
      if (!obj || !obj.method) continue;

      if (obj.method === 'handshake') {
        const projectId = String(obj.project_id || 'default');
        const user = obj.user ? String(obj.user) : null;
        meta.project_id = projectId;
        meta.user = user;
        const room = getRoom(projectId);
        // 把当前房间已有值回灌给新连接
        for (const [name, value] of room.entries()) {
          try {
            ws.send(JSON.stringify({ method: 'set', name, value }));
          } catch (e) { /* ignore */ }
        }
      } else if (obj.method === 'set') {
        if (!meta.project_id) return; // 必须先握手
        if (typeof obj.name !== 'string') return;
        const value = String(obj.value == null ? '' : obj.value).slice(0, MAX_VALUE);
        getRoom(meta.project_id).set(obj.name, value);
        broadcast(meta.project_id, { method: 'set', name: obj.name, value }, ws);
      }
    }
  });

  ws.on('close', () => { clients.delete(ws); });
  ws.on('error', () => { try { ws.close(); } catch (e) { /* ignore */ } });
});

server.listen(PORT, HOST, () => {
  console.log('Cloud List Server 已启动');
  console.log('  WebSocket: ws://' + HOST + ':' + PORT + '/');
  console.log('  调试页:   http://' + HOST + ':' + PORT + '/');
  console.log('扩展里填写: ws://这里填你电脑的局域网IP:' + PORT + '/');
});
