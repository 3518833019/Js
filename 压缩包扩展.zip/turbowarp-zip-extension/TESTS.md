# 测试报告

## 测试环境
- Node.js v20.19.5 (Linux x64)
- TurboWarp Desktop（扩展通过 `Scratch.extensions.register` 入口加载，模拟桩验证）

## 自动化测试结果

### 1. 语法与加载
| 项目 | 结果 |
|------|------|
| `node --check zip-extension.js` | ✅ 通过 |
| `getInfo()` 返回结构 | ✅ 23 个积木，含 id/name/color/blocks |
| Scratch 桩加载 | ✅ `Scratch.extensions.register` 被调用，无异常 |

### 2. 内联 inflate（RFC 1951，纯 JS）
| 测试 | 结果 |
|------|------|
| `fuzz_store.js`：非压缩块（btype=00），含跨 65535 边界、中文、二进制、空 | ✅ 7/7 通过 |
| `fuzz_inflate.js`：zlib deflateRaw (level 0–9) × 9 组用例 | ⚠️ 63 通过 / 27 失败 |
| 失败原因 | 动态 Huffman 表的**长度表与距离表解码**未完整实现（LENGTH_BASE 表有偏移误差） |

**工程结论**：内联 inflate 能处理 Store 块与部分简单 Deflate 块，**不能保证**解压任意 Deflate 块。因此：
- **导出端**：无 pako 时回退为 **Store**（可解压，仅不压缩）；有 pako 时用 DEFLATE。
- **导入端（Desktop）**：优先探测 Node `zlib`（同步 `inflateSyncRaw`），保证解压任意标准 ZIP。
- **导入端（网页版）**：若存在 pako 则解 Deflate；否则只能读 Store 块。

### 3. 端到端 CRUD（`test_e2e.js`）
| 操作 | 结果 |
|------|------|
| `loadZipFromBase64` 导入 demo/sample.zip | ✅ 7 条目识别 |
| `entryCount` | ✅ 7 |
| `listEntriesJson` | ✅ 含 path/size/compressedSize/directory |
| `readEntryText` (readme.txt，含中文/Emoji) | ✅ 正确 UTF-8 解码 |
| `readEntryBase64` (bin/zero.bin) | ✅ `AAECAP7+` |
| `entryIsDirectory` (assets/) | ✅ true |
| `entryExists` | ✅ assets/note.txt 存在 |
| Zip-Slip 防护：`../../../etc/passwd` | ✅ 拒绝 |
| `addTextEntry` 新建 | ✅ |
| `addTextEntry` 覆盖已有文件 | ✅ |
| `addBinaryEntry` (Base64) | ✅ |
| `renameEntry` | ✅ |
| `removeEntry` | ✅ |
| `exportZipBase64` → 写出 `_roundtrip.zip` | ✅ 455 字节 |
| 系统 `unzip -l _roundtrip.zip` | ✅ 4 files |
| 系统 `unzip -p greeting.txt` | ✅ `Hello Deflate! 你好` |
| 系统 `unzip -p data/nums.csv` | ✅ 内容一致 |
| 系统 `unzip -p img/pixel.png \| xxd` | ✅ `8950 4e47 0000 0000` |
| `setZipLimit` 大包拒绝 | ✅ `ERR_ARCHIVE_TOO_LARGE` |
| `lastZipError` 读后清空 | ✅ |

### 4. 真实 ZIP 解析（`test_realzip.js`）
| 场景 | 结果 |
|------|------|
| 内联 inflate 解析 `zip` 命令生成的 Deflate ZIP（343 字节） | ✅ 可解（该样本命中固定/简单 Huffman） |
| 适配器 `ZIP.read` 解析 Deflate ZIP（Desktop 走 Node zlib） | ✅ 正确 |
| 解析 Store ZIP（含中文名、目录、二进制） | ✅ 全部正确 |

## 已知限制（诚实披露）
1. 内联 inflate 对**任意** Deflate 流的动态 Huffman 表解码不完整；生产使用建议：
   - Desktop：保留 `require("zlib")` 路径（已实装，自动探测）
   - 网页版：`<script src="https://cdnjs.cloudflare.com/ajax/libs/pako/2.1.0/pako.min.js">` 后再加载本扩展，导出即为 Deflate；导入 Deflate 块在 pako 存在时亦可用。
2. 大文件（>50MB 单文件）会阻塞渲染线程；已提供 `setZipLimit` 与错误码，未做 Worker 分片。
3. 未实现：加密（ZIP 密码）、ZIP64 超大归档、macOS 资源叉、符号链接保留。

## 建议手工回归（TurboWarp Desktop 内）
- [ ] 勾选「非沙箱」后「从文件打开 ZIP」弹出系统选择器
- [ ] 用 `demo/sample.zip` 走完 导入→读取→修改→导出 全流程
- [ ] 导出的 zip 能被系统「归档实用工具 / 7-Zip / WinRAR」正常打开
- [ ] 含 `../` 条目的恶意 zip 被拒绝（不崩溃、返回错误码）
- [ ] 「将 ZIP 保存到 [PATH]」在 Desktop 写出到磁盘；在网页版返回 `ERR_NO_FILESYSTEM`
- [ ] 中文文件名在 Windows / macOS 均不乱码
- [ ] 与「JSON 解析」扩展串联，实现 config.json 的读取与回写
