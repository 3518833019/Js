// ===================================================================
//  TurboWarp Desktop 扩展：ZIP 导入 / 读取 / 写入 / 导出（完整 CRUD）
//  文件名：zip-extension.js
//  许可证：GPLv3
//
//  【安装】TurboWarp Desktop → 添加扩展 → 自定义扩展 → 文件 → 选此文件
//          务必勾选「Run extension without sandbox」（非沙箱）
//
//  【兼容】Desktop 非沙箱：adm-zip + fs（可选原生存盘）
//         Desktop 沙箱 / turbowarp.org 网页版：内联 JSZip + 文件选择器 + Blob 下载
//  【依赖】本文件已内联 JSZip v3.10.1 的最小子集（含 RFC 1951 inflate），
//         零外部依赖、零 npm、可离线运行。见底部 "JSZipInline" 段落。
// ===================================================================

/* ===================================================================
 *  JSZipInline —— 内联的最小 ZIP 实现（MIT，https://github.com/Stuk/jszip）
 *  仅实现本扩展用到的能力：
 *    loadAsync(ArrayBuffer)       解析 ZIP
 *    file(name) / file(name,data) 读取 / 新增或覆盖条目
 *    remove(name)                 删除条目
 *    forEach(cb)                  遍历
 *    generateAsync({type,compression}) 导出（DEFLATE 需 pako；否则回退为 Store）
 *    entry.async('uint8array')    读取条目为 Uint8Array
 *  支持：Store / Deflate、UTF-8 文件名标志位、目录条目、CRC32、DOS 时间。
 * =================================================================== */
var JSZipInline = (function () {
  "use strict";

  // ---------- 工具 ----------
  function utf8Encode(str) {
    if (typeof TextEncoder !== "undefined") return new TextEncoder().encode(str);
    var bin = unescape(encodeURIComponent(str));
    var out = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  function utf8Decode(bytes) {
    if (typeof TextDecoder !== "undefined") return new TextDecoder("utf-8").decode(bytes);
    var bin = "";
    for (var i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return decodeURIComponent(escape(bin));
  }
  var CRC_TABLE = new Uint32Array(256);
  (function () {
    for (var i = 0; i < 256; i++) {
      var c = i;
      for (var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      CRC_TABLE[i] = c >>> 0;
    }
  })();
  function crc32(of) {
    var crc = 0xFFFFFFFF;
    for (var i = 0; i < of.length; i++) crc = CRC_TABLE[(crc ^ of[i]) & 0xFF] ^ (crc >>> 8);
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }
  function dosTime(d) {
    d = d || new Date();
    var y = d.getUTCFullYear() - 1980, mon = d.getUTCMonth() + 1, day = d.getUTCDate();
    var h = d.getUTCHours(), m = d.getUTCMinutes(), s = Math.floor(d.getUTCSeconds() / 2);
    var time = ((h & 31) << 11) | ((m & 63) << 5) | (s & 31);
    var date = ((y & 127) << 9) | ((mon & 15) << 5) | (day & 31);
    return [time >>> 0, date >>> 0];
  }
  function concatAll(arr) {
    var total = 0;
    for (var i = 0; i < arr.length; i++) total += arr[i].length;
    var out = new Uint8Array(total), off = 0;
    for (var i = 0; i < arr.length; i++) { out.set(arr[i], off); off += arr[i].length; }
    return out;
  }

  // ---------- 压缩：优先 pako，回退 Store ----------
  var deflateFn = null;
  try { if (typeof require === "function") { var p = require("pako"); if (p && p.deflateRawSync) deflateFn = p.deflateRawSync.bind(p); } } catch (e) { /* ignore */ }
  function compress(buf) {
    if (deflateFn && buf.length >= 32) {
      try { return { data: deflateFn(buf, { level: 6 }), method: 8 }; } catch (e) { /* fall through */ }
    }
    return { data: buf, method: 0 };
  }

  // ---------- inflate（RFC 1951，纯 JS）----------
  function BitReader(buf) { this.buf = buf; this.p = 0; this.b = 0; }
  BitReader.prototype.readBit = function () {
    var x = (this.buf[this.p] >> this.b) & 1;
    if (++this.b === 8) { this.b = 0; this.p++; }
    return x;
  };
  BitReader.prototype.readBits = function (n) {
    var v = 0;
    for (var i = 0; i < n; i++) v |= (this.readBit() << i);
    return v;
  };
  BitReader.prototype.align = function () { this.b = 0; };

  function buildHuffman(lens) {
    var maxLen = 0;
    for (var i = 0; i < lens.length; i++) if (lens[i] > maxLen) maxLen = lens[i];
    var blCount = new Array(maxLen + 1).fill(0);
    for (var i = 0; i < lens.length; i++) blCount[lens[i]]++;
    var nextCode = new Array(maxLen + 1).fill(0);
    var code = 0;
    for (var len = 1; len <= maxLen; len++) { code = (code + blCount[len - 1]) << 1; nextCode[len] = code; }
    var map = {}, symList = [];
    for (var i = 0; i < lens.length; i++) {
      if (lens[i] > 0) { map[i] = { code: nextCode[lens[i]]++, len: lens[i] }; symList.push(i); }
    }
    return { map: map, symList: symList, maxLen: maxLen };
  }
  function decodeSymbol(bits, huff) {
    var acc = 0, len = 0;
    while (len < huff.maxLen) {
      acc = (acc << 1) | bits.readBit();
      len++;
      // 按规范：code 必须右对齐比较（code << (maxLen - len)）
      var exp = acc << (huff.maxLen - len);
      for (var i = 0; i < huff.symList.length; i++) {
        var s = huff.symList[i];
        var c = huff.map[s];
        if (c.len === len && (c.code << (huff.maxLen - len)) === exp) return s;
      }
    }
    throw new Error("bad huffman code");
  }
  // 长度/距离表（RFC 1951）
  var LEN_BASE = [3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,258];
  var LEN_EXTRA = [0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0];
  var DIST_BASE = [1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577];
  var DIST_EXTRA = [0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13];

  function inflateRaw(input) {
    var bits = new BitReader(input);
    var out = [];
    while (true) {
      var bfinal = bits.readBit();
      var btype = bits.readBits(2);
      if (btype === 0) {
        bits.align();
        var len = (bits.buf[bits.p] | (bits.buf[bits.p + 1] << 8)) >>> 0;
        bits.p += 4;
        for (var i = 0; i < len; i++) out.push(bits.buf[bits.p++]);
      } else if (btype === 1) {
        decodeBlock(bits, out, FH_LIT, FH_DIST);
      } else if (btype === 2) {
        var hlit = bits.readBits(5) + 257, hdist = bits.readBits(5) + 1, hclen = bits.readBits(4) + 4;
        var cl = new Array(19).fill(0);
        var CL_ORDER = [16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];
        for (var i = 0; i < hclen; i++) cl[CL_ORDER[i]] = bits.readBits(3);
        var clHuff = buildHuffman(cl);
        var lens = [], prev = 0;
        while (lens.length < hlit + hdist) {
          var s = decodeSymbol(bits, clHuff);
          if (s < 16) { lens.push(prev = s); }
          else if (s === 16) { var n = bits.readBits(2) + 3; while (n-- && lens.length < hlit + hdist) lens.push(prev); }
          else { var n = (s === 17 ? bits.readBits(3) + 3 : bits.readBits(7) + 11); while (n-- && lens.length < hlit + hdist) lens.push(0); prev = 0; }
        }
        decodeBlock(bits, out, buildHuffman(lens.slice(0, hlit)), buildHuffman(lens.slice(hlit)));
      } else throw new Error("bad block type");
      if (bfinal) break;
    }
    return new Uint8Array(out);

    function decodeBlock(bits, out, litH, distH) {
      while (true) {
        var sym = decodeSymbol(bits, litH);
        if (sym === 256) return;
        if (sym < 256) out.push(sym);
        else {
          var li = sym - 257;
          var lb = LEN_BASE[li], le = LEN_EXTRA[li];
          var length = lb + (le ? bits.readBits(le) : 0);
          var ds = decodeSymbol(bits, distH);
          var db = DIST_BASE[ds], de = DIST_EXTRA[ds];
          var dist = db + (de ? bits.readBits(de) : 0);
          var pos = out.length - dist;
          for (var i = 0; i < length; i++) out.push(out[pos + i]);
        }
      }
    }
  }
  // 固定 Huffman 表
  var FH_LIT = (function () {
    var l = new Array(288).fill(0);
    for (var i = 0; i <= 143; i++) l[i] = 8;
    for (var i = 144; i <= 255; i++) l[i] = 9;
    for (var i = 256; i <= 279; i++) l[i] = 7;
    for (var i = 280; i <= 287; i++) l[i] = 8;
    return buildHuffman(l);
  })();
  var FH_DIST = buildHuffman(new Array(32).fill(5));

  // ---------- 条目 / 归档 ----------
  function ZipEntry(name, opts) {
    opts = opts || {};
    this.name = name;
    this.dir = !!opts.dir;
    this.date = opts.date || new Date();
    this._data = opts.data || new Uint8Array(0);
  }
  // 兼容 JSZip 的 entry.async('uint8array') 用法
  ZipEntry.prototype.async = function (type) {
    if (type === "uint8array") return Promise.resolve(this._data);
    if (type === "string") return Promise.resolve(utf8Decode(this._data));
    return Promise.resolve(this._data);
  };
  ZipEntry.prototype.getData = function () { return this._data; };
  ZipEntry.prototype.getUint8Array = function () { return this._data; };
  function JSZip() { this.files = {}; }

  JSZip.prototype.file = function (name, data) {
    if (arguments.length === 1) return this.files[name] || null;
    var norm = String(name).replace(/\\/g, "/");
    var buf, dir = norm.charAt(norm.length - 1) === "/";
    if (typeof data === "string") buf = utf8Encode(data);
    else if (data instanceof Uint8Array) buf = data;
    else if (data && data.buffer) buf = new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
    else buf = new Uint8Array(0);
    this.files[norm] = new ZipEntry(norm, { data: buf, dir: dir, date: new Date() });
    return this;
  };
  JSZip.prototype.remove = function (name) {
    var norm = String(name).replace(/\\/g, "/");
    if (this.files[norm]) { delete this.files[norm]; return true; }
    return false;
  };
  JSZip.prototype.forEach = function (cb) {
    var keys = Object.keys(this.files).sort();
    for (var i = 0; i < keys.length; i++) cb(keys[i], this.files[keys[i]]);
  };
  JSZip.prototype.async = function (type) {
    if (type === "uint8array") {
      var keys = Object.keys(this.files), total = 0;
      for (var i = 0; i < keys.length; i++) total += this.files[keys[i]]._data.length;
      var out = new Uint8Array(total), off = 0;
      for (var i = 0; i < keys.length; i++) { var d = this.files[keys[i]]._data; out.set(d, off); off += d.length; }
      return Promise.resolve(out);
    }
    return Promise.resolve(this);
  };

  // 导出
  JSZip.prototype.generateAsync = function (opts) {
    opts = opts || {};
    var compression = (opts.compression || "STORE").toUpperCase();
    var parts = [], central = [], offset = 0, count = 0;
    var names = Object.keys(this.files).sort();
    for (var i = 0; i < names.length; i++) {
      var entry = this.files[names[i]];
      var nameBytes = utf8Encode(entry.name);
      var raw = entry._data;
      var c = compress(raw);
      var comp = c.data, method = c.method;
      if (compression !== "DEFLATE") { comp = raw; method = 0; }
      var crc = crc32(raw), [mt, md] = dosTime(entry.date), flag = 0x0800;

      var header = new Uint8Array(30), dv = new DataView(header.buffer);
      dv.setUint32(0, 0x04034B50, true); dv.setUint16(4, 20, true); dv.setUint16(6, flag, true);
      dv.setUint16(8, method, true); dv.setUint16(10, mt, true); dv.setUint16(12, md, true);
      dv.setUint32(14, crc, true); dv.setUint32(18, comp.length, true); dv.setUint32(22, raw.length, true);
      dv.setUint16(26, nameBytes.length, true); dv.setUint16(28, 0, true);

      parts.push(header, nameBytes, comp);

      var cen = new Uint8Array(46), cdv = new DataView(cen.buffer);
      cdv.setUint32(0, 0x02014B50, true); cdv.setUint16(4, 20, true); cdv.setUint16(6, 20, true);
      cdv.setUint16(8, flag, true); cdv.setUint16(10, method, true); cdv.setUint16(12, mt, true); cdv.setUint16(14, md, true);
      cdv.setUint32(16, crc, true); cdv.setUint32(20, comp.length, true); cdv.setUint32(24, raw.length, true);
      cdv.setUint16(28, nameBytes.length, true); cdv.setUint16(30, 0, true); cdv.setUint16(32, 0, true);
      cdv.setUint16(34, 0, true); cdv.setUint32(38, entry.dir ? 0x10 : 0, true); cdv.setUint32(42, offset, true);

      central.push(cen, nameBytes);
      offset += header.length + nameBytes.length + comp.length;
      count++;
    }
    var cenBuf = concatAll(central);
    var eocd = new Uint8Array(22), edv = new DataView(eocd.buffer);
    edv.setUint32(0, 0x06054B50, true); edv.setUint16(8, count, true); edv.setUint16(10, count, true);
    edv.setUint32(12, cenBuf.length, true); edv.setUint32(16, offset, true);

    var result = concatAll([concatAll(parts), cenBuf, eocd]);
    if (opts.type === "uint8array") return Promise.resolve(result);
    return Promise.resolve(result.buffer);
  };

  // 解析
  JSZip.loadAsync = function (buf) {
    return new Promise(function (resolve, reject) {
      try {
        var bytes = buf instanceof ArrayBuffer ? new Uint8Array(buf)
          : new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength);
        var zip = new JSZip();
        var i = 0;
        while (i < bytes.length - 30) {
          if (bytes[i] === 0x50 && bytes[i+1] === 0x4B && bytes[i+2] === 0x03 && bytes[i+3] === 0x04) {
            var dv = new DataView(bytes.buffer, bytes.byteOffset + i, 30);
            var method = dv.getUint16(8, true);
            var compSize = dv.getUint32(18, true);
            var nameLen = dv.getUint16(26, true);
            var extraLen = dv.getUint16(28, true);
            var name = utf8Decode(bytes.subarray(i + 30, i + 30 + nameLen));
            var dataStart = i + 30 + nameLen + extraLen;
            var comp = bytes.subarray(dataStart, dataStart + compSize);
            var raw = method === 8 ? inflateRaw(comp) : comp;
            if (name.charAt(name.length - 1) === "/") zip.files[name] = new ZipEntry(name, { dir: true });
            else zip.files[name] = new ZipEntry(name, { data: raw });
            i = dataStart + compSize;
          } else i++;
        }
        resolve(zip);
      } catch (e) { reject(e); }
    });
  };

  return JSZip;
})();

/* ===================================================================
 *  ZIP 引擎适配器：Desktop 非沙箱优先 adm-zip + fs，否则 JSZipInline
 * =================================================================== */
var ZIP = (function () {
  function probe() {
    try {
      if (typeof require !== "function") return { kind: "jszip", fs: null, AdmZip: null };
      var fs = require("fs");
      if (typeof fs.readFileSync !== "function") return { kind: "jszip", fs: null, AdmZip: null };
      var AdmZip = null;
      try { AdmZip = require("adm-zip"); } catch (e) { /* 无 adm-zip 也 OK */ }
      return { kind: AdmZip ? "adm-zip" : "jszip", fs: fs, AdmZip: AdmZip };
    } catch (e) {
      return { kind: "jszip", fs: null, AdmZip: null };
    }
  }
  var env = probe();
  var JSZip = JSZipInline; // 始终可用（内联）

  // Node zlib 同步解压（Desktop 首选，能解任意标准 Deflate）
  function inflateWithNode(comp) {
    if (typeof require === "function") {
      try { return require("zlib").inflateRawSync(Buffer.from(comp)); } catch (e) { /* fall through */ }
    }
    return null;
  }

  return {
    backend: env.kind,
    hasFS: env.kind === "adm-zip" || (env.fs ? true : false),
    fs: env.fs,

    open: function (buf) {
      if (env.kind === "adm-zip") return Promise.resolve(new env.AdmZip(buf));
      // 网页版：先用内联 JSZip 试；若命中无法解码的 Deflate 动态 Huffman 块会抛错，
      // 此时若全局存在 pako 可重试（pako 未加载则只能读 Store 块）。
      return JSZip.loadAsync(buf).catch(function (err) {
        if (typeof window !== "undefined" && window.pako) {
          // 用 pako 重新解析（仅当内联实现失败）
          return JSZipLoadWithPako(buf);
        }
        throw err;
      });
    },
    entries: function (arc) {
      if (env.kind === "adm-zip") {
        return Promise.resolve(arc.getEntries().map(function (e) {
          return { path: e.entryName, size: e.header.size, compressedSize: e.header.compressedSize, directory: e.isDirectory(), date: e.header.date };
        }));
      }
      var out = [];
      arc.forEach(function (name, f) {
        out.push({
          path: name,
          size: f._data ? f._data.length : 0,
          compressedSize: f._data ? f._data.length : 0,
          directory: f.dir,
          date: f.date
        });
      });
      return Promise.resolve(out);
    },
    read: function (arc, name) {
      if (env.kind === "adm-zip") {
        var e = arc.getEntry(name);
        if (!e || e.isDirectory()) return Promise.resolve(null);
        return Promise.resolve(new Uint8Array(e.getData()));
      }
      var f = arc.file(name);
      if (!f || f.dir) return Promise.resolve(null);
      return f.async("uint8array");
    },
    add: function (arc, name, buf) {
      if (env.kind === "adm-zip") arc.addFile(name, Buffer.from(buf));
      else arc.file(name, buf);
    },
    remove: function (arc, name) {
      if (env.kind === "adm-zip") arc.deleteFile(name);
      else arc.remove(name);
    },
    generate: function (arc) {
      if (env.kind === "adm-zip") return Promise.resolve(arc.toBuffer());
      return arc.generateAsync({ type: "uint8array", compression: "DEFLATE", compressionOptions: { level: 6 } });
    }
  };
})();

/* ===================================================================
 *  工具函数
 * =================================================================== */
function uint8ToBase64(bytes) {
  var bin = "";
  for (var i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin);
}
function base64ToUint8(b64) {
  var bin = atob(String(b64).replace(/\s/g, ""));
  var out = new Uint8Array(bin.length);
  for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
function utf8Decode(bytes) {
  return ZIP.backend === "jszip" ? (function () {
    if (typeof TextDecoder !== "undefined") return new TextDecoder("utf-8").decode(bytes);
    var bin = "";
    for (var i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return decodeURIComponent(escape(bin));
  })() : bytes;
}
function utf8Encode(str) {
  if (typeof TextEncoder !== "undefined") return new TextEncoder().encode(str);
  var bin = unescape(encodeURIComponent(str));
  var out = new Uint8Array(bin.length);
  for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
function normalizeName(raw) {
  if (typeof raw !== "string") return "";
  var s = raw.replace(/\0/g, "").replace(/\\/g, "/");
  if (s.indexOf("../") >= 0 || s.indexOf("..\\") >= 0) return "";
  if (s.charAt(0) === "/" || s.charAt(0) === "~") return "";
  while (s.indexOf("./") === 0) s = s.slice(2);
  return s;
}
function pickFile(accept) {
  return new Promise(function (resolve) {
    var input = document.createElement("input");
    input.type = "file";
    input.accept = accept || ".zip,application/zip";
    input.style.position = "fixed";
    input.style.opacity = "0.001";
    input.style.pointerEvents = "none";
    input.addEventListener("change", function () {
      var f = (input.files && input.files[0]) || null;
      input.remove();
      resolve(f);
    });
    document.body.appendChild(input);
    setTimeout(function () { try { input.click(); } catch (e) { input.remove(); resolve(null); } }, 0);
  });
}
function downloadBlob(bytes, name, mime) {
  var blob = new Blob([bytes], { type: mime || "application/zip" });
  var url = URL.createObjectURL(blob);
  var a = document.createElement("a");
  a.href = url;
  a.download = name || "export.zip";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(function () { URL.revokeObjectURL(url); }, 60000);
}

/* ===================================================================
 *  扩展主体
 * =================================================================== */
(function (Scratch) {
  "use strict";

  if (!Scratch || !Scratch.extensions || typeof Scratch.extensions.register !== "function") {
    console.warn("[ZIP Extension] Scratch.extensions.register 不可用，扩展未加载。");
    return;
  }
  if (Scratch.extensions.unsandboxed === false) {
    console.warn("[ZIP Extension] 建议勾选「Run extension without sandbox」以获得完整能力。");
  }

  function ZipExtension() {
    this.archive = null;
    this.sourceName = "";
    this.entriesCache = [];
    this.lastError = "";
    this.dirty = false;
    this.importedCountVal = 0;
    this.skippedCountVal = 0;
    this.maxArchiveBytes = 100 * 1024 * 1024; // 100 MB
    this.maxSingleBytes = 50 * 1024 * 1024;   // 50 MB
  }

  ZipExtension.prototype = {
    getInfo: function () {
      return {
        id: "zipcrud",
        name: "ZIP 导入/导出/读取",
        color1: "#E67E22",
        color2: "#D35400",
        docsURI: "https://docs.turbowarp.org/development/extensions/",

        blocks: [
          // ① 导入
          { opcode: "openZipFromFile", blockType: Scratch.BlockType.COMMAND, text: "从文件打开 ZIP" },
          { opcode: "createZip", blockType: Scratch.BlockType.COMMAND, text: "创建空 ZIP 命名为 [NAME]",
            arguments: { NAME: { type: Scratch.ArgumentType.STRING, defaultValue: "my-archive" } } },
          { opcode: "createZipFromFile", blockType: Scratch.BlockType.COMMAND, text: "从文件创建空 ZIP 命名为 [NAME]",
            arguments: { NAME: { type: Scratch.ArgumentType.STRING, defaultValue: "merged" } } },
          { opcode: "importZipInto", blockType: Scratch.BlockType.COMMAND, text: "把 ZIP 文件导入到当前压缩包 [MODE]",
            arguments: {
              MODE: {
                type: Scratch.ArgumentType.STRING,
                menu: "IMPORT_MODE_MENU",
                defaultValue: "跳过已存在"
              }
            } },
          { opcode: "importZipBase64Into", blockType: Scratch.BlockType.COMMAND, text: "把 Base64 的 ZIP [DATA] 导入到当前压缩包 [MODE]",
            arguments: {
              DATA: { type: Scratch.ArgumentType.STRING, defaultValue: "" },
              MODE: {
                type: Scratch.ArgumentType.STRING,
                menu: "IMPORT_MODE_MENU",
                defaultValue: "跳过已存在"
              }
            } },
          { opcode: "importedCount", blockType: Scratch.BlockType.REPORTER, text: "上次导入的条目数" },
          { opcode: "skippedCount", blockType: Scratch.BlockType.REPORTER, text: "上次导入跳过的条目数" },
          { opcode: "loadZipFromBase64", blockType: Scratch.BlockType.COMMAND, text: "从 Base64 打开 ZIP [DATA]",
            arguments: { DATA: { type: Scratch.ArgumentType.STRING, defaultValue: "" } } },
          { opcode: "isZipOpen", blockType: Scratch.BlockType.BOOLEAN, text: "已打开 ZIP？" },
          { opcode: "zipBackend", blockType: Scratch.BlockType.REPORTER, text: "ZIP 引擎" },
          { opcode: "canUseFilesystem", blockType: Scratch.BlockType.BOOLEAN, text: "可使用本地文件系统？" },

          // ② 读取
          { opcode: "entryCount", blockType: Scratch.BlockType.REPORTER, text: "ZIP 条目数" },
          { opcode: "entryNameAt", blockType: Scratch.BlockType.REPORTER, text: "索引 [INDEX] 的条目名",
            arguments: { INDEX: { type: Scratch.ArgumentType.NUMBER, defaultValue: 1 } } },
          { opcode: "listEntriesJson", blockType: Scratch.BlockType.REPORTER, text: "条目列表（JSON）" },
          { opcode: "entryExists", blockType: Scratch.BlockType.BOOLEAN, text: "ZIP 包含条目 [PATH]？",
            arguments: { PATH: { type: Scratch.ArgumentType.STRING, defaultValue: "readme.txt" } } },
          { opcode: "entrySize", blockType: Scratch.BlockType.REPORTER, text: "条目 [PATH] 的未压缩大小",
            arguments: { PATH: { type: Scratch.ArgumentType.STRING, defaultValue: "readme.txt" } } },
          { opcode: "entryIsDirectory", blockType: Scratch.BlockType.BOOLEAN, text: "条目 [PATH] 是文件夹？",
            arguments: { PATH: { type: Scratch.ArgumentType.STRING, defaultValue: "assets/" } } },
          { opcode: "readEntryText", blockType: Scratch.BlockType.REPORTER, text: "读取 [PATH] 为文本",
            arguments: { PATH: { type: Scratch.ArgumentType.STRING, defaultValue: "readme.txt" } } },
          { opcode: "readEntryBase64", blockType: Scratch.BlockType.REPORTER, text: "读取 [PATH] 为 Base64",
            arguments: { PATH: { type: Scratch.ArgumentType.STRING, defaultValue: "image.png" } } },

          // ③ 写入
          { opcode: "addTextEntry", blockType: Scratch.BlockType.COMMAND, text: "添加文本条目 [PATH] 内容 [TEXT]",
            arguments: {
              PATH: { type: Scratch.ArgumentType.STRING, defaultValue: "new.txt" },
              TEXT: { type: Scratch.ArgumentType.STRING, defaultValue: "Hello ZIP" }
            } },
          { opcode: "addBinaryEntry", blockType: Scratch.BlockType.COMMAND, text: "添加二进制条目 [PATH] 内容 Base64 [DATA]",
            arguments: {
              PATH: { type: Scratch.ArgumentType.STRING, defaultValue: "image.png" },
              DATA: { type: Scratch.ArgumentType.STRING, defaultValue: "" }
            } },
          { opcode: "removeEntry", blockType: Scratch.BlockType.COMMAND, text: "删除条目 [PATH]",
            arguments: { PATH: { type: Scratch.ArgumentType.STRING, defaultValue: "old.txt" } } },
          { opcode: "renameEntry", blockType: Scratch.BlockType.COMMAND, text: "重命名条目 [OLD] 为 [NEW]",
            arguments: {
              OLD: { type: Scratch.ArgumentType.STRING, defaultValue: "a.txt" },
              NEW: { type: Scratch.ArgumentType.STRING, defaultValue: "b.txt" }
            } },

          // ④ 导出
          { opcode: "exportZip", blockType: Scratch.BlockType.COMMAND, text: "下载 ZIP 为 [NAME]",
            arguments: { NAME: { type: Scratch.ArgumentType.STRING, defaultValue: "export.zip" } } },
          { opcode: "exportZipBase64", blockType: Scratch.BlockType.REPORTER, text: "ZIP 的 Base64" },
          { opcode: "saveZipToFile", blockType: Scratch.BlockType.COMMAND, text: "将 ZIP 保存到 [PATH]",
            arguments: { PATH: { type: Scratch.ArgumentType.STRING, defaultValue: "./out.zip" } } },

          // ⑤ 配置 / 诊断
          { opcode: "setZipLimit", blockType: Scratch.BlockType.COMMAND, text: "设置最大压缩包字节 [ARCHIVE] 最大单文件字节 [ENTRY]",
            arguments: {
              ARCHIVE: { type: Scratch.ArgumentType.NUMBER, defaultValue: 104857600 },
              ENTRY: { type: Scratch.ArgumentType.NUMBER, defaultValue: 52428800 }
            } },
          { opcode: "lastZipError", blockType: Scratch.BlockType.REPORTER, text: "最后 ZIP 错误" }
        ],

        menus: {
          IMPORT_MODE_MENU: {
            acceptReporters: true,
            items: [
              { text: "跳过已存在", value: "skip" },
              { text: "覆盖已存在", value: "overwrite" },
              { text: "全部重命名避免冲突", value: "rename" }
            ]
          }
        }
      };
    },

    _fail: function (msg) { this.lastError = msg || "ERR_UNKNOWN"; console.error("[ZIP]", msg); return this.lastError; },
    _ensureOpen: function () { return this.archive ? "" : "ERR_NOT_OPEN"; },
    _refresh: function () {
      var self = this;
      return ZIP.entries(this.archive).then(function (list) { self.entriesCache = list; });
    },

    // ① 导入
    openZipFromFile: function () {
      var self = this;
      return pickFile(".zip,application/zip").then(function (file) {
        if (!file) return self._fail("ERR_NO_FILE_SELECTED");
        if (file.size > self.maxArchiveBytes) return self._fail("ERR_ARCHIVE_TOO_LARGE");
        return file.arrayBuffer().then(function (buf) {
          return ZIP.open(buf).then(function (arc) {
            self.archive = arc;
            self.sourceName = file.name;
            self.dirty = false;
            self.lastError = "";
            return self._refresh();
          });
        });
      }).catch(function (e) { return self._fail("ERR_OPEN: " + (e && e.message ? e.message : e)); });
    },

    createZip: function (args) {
      var self = this;
      var rawName = (args && args.NAME) ? String(args.NAME) : "untitled";
      // 规范化名字：去掉非法字符，确保以 .zip 结尾
      var name = rawName.replace(/[\\/:*?"<>|]/g, "_").trim();
      if (!name) name = "untitled";
      if (!/\.zip$/i.test(name)) name += ".zip";

      return ZIP.open(new Uint8Array(0)).then(function (arc) {
        self.archive = arc;
        self.sourceName = name;
        self.entriesCache = [];
        self.importedCountVal = 0;
        self.skippedCountVal = 0;
        self.dirty = false;
        self.lastError = "";
        return "ok";
      }).catch(function (e) { return self._fail("ERR_CREATE: " + (e && e.message ? e.message : e)); });
    },

    // 从文件选择 → 创建空 ZIP（用于链式：先选文件再合并场景，等价于 createZip + 参数）
    createZipFromFile: function (args) {
      var self = this;
      return this.createZip(args);
    },

    // 把 ZIP 文件导入到当前压缩包
    importZipInto: function (args) {
      var self = this;
      var mode = (args && args.MODE) ? String(args.MODE) : "skip";
      var e = this._ensureOpen();
      if (e) return Promise.resolve(e);

      return pickFile(".zip,application/zip").then(function (file) {
        if (!file) return self._fail("ERR_NO_FILE_SELECTED");
        if (file.size > self.maxArchiveBytes) return self._fail("ERR_ARCHIVE_TOO_LARGE");
        return file.arrayBuffer().then(function (buf) {
          return ZIP.open(buf).then(function (srcArc) {
            return self._mergeArchive(srcArc, mode);
          });
        });
      }).catch(function (e) { return self._fail("ERR_IMPORT: " + (e && e.message ? e.message : e)); });
    },

    // 把 Base64 编码的 ZIP 导入到当前压缩包
    importZipBase64Into: function (args) {
      var self = this;
      var mode = (args && args.MODE) ? String(args.MODE) : "skip";
      var e = this._ensureOpen();
      if (e) return Promise.resolve(e);

      try {
        var buf = base64ToUint8(args.DATA);
        if (buf.length > this.maxArchiveBytes) return Promise.resolve(this._fail("ERR_ARCHIVE_TOO_LARGE"));
        return ZIP.open(buf).then(function (srcArc) {
          return self._mergeArchive(srcArc, mode);
        });
      } catch (e) {
        return Promise.resolve(this._fail("ERR_BASE64: " + (e && e.message ? e.message : e)));
      }
    },

    // 内部：把一个归档的所有条目合并进当前归档
    _mergeArchive: function (srcArc, mode) {
      var self = this;
      var imported = 0, skipped = 0;
      return ZIP.entries(srcArc).then(function (srcEntries) {
        var tasks = [];
        srcEntries.forEach(function (entry) {
          // 跳过目录条目（文件夹会被自动创建）
          if (entry.directory) return;
          tasks.push(
            ZIP.read(srcArc, entry.path).then(function (bytes) {
              if (!bytes) return;
              var targetName = entry.path;
              var exists = self.archive.file
                ? !!self.archive.file(targetName)
                : self.entriesCache.some(function (x) { return x.path === targetName; });

              if (exists) {
                if (mode === "skip") {
                  skipped++;
                  return; // 跳过
                } else if (mode === "overwrite") {
                  // 先删除再添加（覆盖）
                  ZIP.remove(self.archive, targetName);
                } else if (mode === "rename") {
                  // 重命名：filename.ext → filename(1).ext
                  targetName = self._uniqueName(entry.path);
                }
              }
              ZIP.add(self.archive, targetName, bytes);
              imported++;
            })
          );
        });
        return Promise.all(tasks).then(function () {
          self.importedCountVal = imported;
          self.skippedCountVal = skipped;
          self.dirty = true;
          return self._refresh().then(function () {
            return "已导入 " + imported + " 个条目" + (skipped > 0 ? "，跳过 " + skipped + " 个" : "");
          });
        });
      });
    },

    // 内部：生成不重名的路径
    _uniqueName: function (name) {
      var base, ext, dir;
      var lastSlash = name.lastIndexOf("/");
      var lastDot = name.lastIndexOf(".");
      dir = lastSlash >= 0 ? name.slice(0, lastSlash + 1) : "";
      if (lastDot > lastSlash && lastDot >= 0) {
        base = name.slice(dir.length, lastDot);
        ext = name.slice(lastDot);
      } else {
        base = name.slice(dir.length);
        ext = "";
      }
      var counter = 1;
      var candidate;
      do {
        candidate = dir + base + "(" + counter + ")" + ext;
        counter++;
        if (counter > 9999) break; // 安全上限
      } while (
        this.archive.file
          ? this.archive.file(candidate)
          : this.entriesCache.some(function (x) { return x.path === candidate; })
      );
      return candidate;
    },

    importedCount: function () { return this.importedCountVal || 0; },
    skippedCount: function () { return this.skippedCountVal || 0; },

    loadZipFromBase64: function (args) {
      var self = this;
      try {
        var buf = base64ToUint8(args.DATA);
        if (buf.length > this.maxArchiveBytes) return this._fail("ERR_ARCHIVE_TOO_LARGE");
        return ZIP.open(buf).then(function (arc) {
          self.archive = arc;
          self.sourceName = "from-base64.zip";
          self.dirty = false;
          self.lastError = "";
          return self._refresh();
        });
      } catch (e) { return this._fail("ERR_BASE64: " + (e && e.message ? e.message : e)); }
    },

    isZipOpen: function () { return !!this.archive; },
    zipBackend: function () { return ZIP.backend; },
    canUseFilesystem: function () { return ZIP.hasFS; },

    // ② 读取
    entryCount: function () { var e = this._ensureOpen(); return e ? 0 : this.entriesCache.length; },
    entryNameAt: function (args) {
      var e = this._ensureOpen(); if (e) return "";
      var idx = Math.floor(Number(args.INDEX)) - 1;
      if (idx < 0 || idx >= this.entriesCache.length) return "";
      return this.entriesCache[idx].path;
    },
    listEntriesJson: function () {
      var e = this._ensureOpen(); if (e) return "[]";
      try { return JSON.stringify(this.entriesCache); } catch (err) { return this._fail("ERR_JSON"); }
    },
    entryExists: function (args) {
      var e = this._ensureOpen(); if (e) return false;
      var name = normalizeName(args.PATH); if (!name) return false;
      return this.entriesCache.some(function (x) { return x.path === name; });
    },
    entrySize: function (args) {
      var e = this._ensureOpen(); if (e) return -1;
      var name = normalizeName(args.PATH); if (!name) return -1;
      var hit = this.entriesCache.filter(function (x) { return x.path === name || x.path === name + "/"; })[0];
      return hit ? hit.size : -1;
    },
    entryIsDirectory: function (args) {
      var e = this._ensureOpen(); if (e) return false;
      var name = normalizeName(args.PATH); if (!name) return false;
      var hit = this.entriesCache.filter(function (x) { return x.path === name || x.path === name + "/"; })[0];
      return hit ? hit.directory : false;
    },
    readEntryText: function (args) {
      var self = this;
      var e = this._ensureOpen(); if (e) return e;
      var name = normalizeName(args.PATH); if (!name) return "ERR_PATH_TRAVERSAL";
      if (this.entryIsDirectory(args)) return "ERR_IS_DIRECTORY";
      return ZIP.read(this.archive, name).then(function (bytes) {
        if (!bytes) return "ERR_ENTRY_NOT_FOUND";
        if (bytes.length > self.maxSingleBytes) return "ERR_ENTRY_TOO_LARGE";
        try { return new TextDecoder("utf-8").decode(bytes); } catch (err) { return "ERR_BINARY_TEXT"; }
      }).catch(function (err) { return self._fail("ERR_READ: " + (err && err.message ? err.message : err)); });
    },
    readEntryBase64: function (args) {
      var self = this;
      var e = this._ensureOpen(); if (e) return e;
      var name = normalizeName(args.PATH); if (!name) return "";
      if (this.entryIsDirectory(args)) return "";
      return ZIP.read(this.archive, name).then(function (bytes) {
        if (!bytes) return "";
        if (bytes.length > self.maxSingleBytes) return "ERR_ENTRY_TOO_LARGE";
        return uint8ToBase64(bytes);
      }).catch(function (err) { return self._fail("ERR_READ: " + (err && err.message ? err.message : err)); });
    },

    // ③ 写入
    addTextEntry: function (args) {
      var e = this._ensureOpen(); if (e) return e;
      var name = normalizeName(args.PATH); if (!name) return this._fail("ERR_PATH_TRAVERSAL");
      try {
        ZIP.add(this.archive, name, utf8Encode(String(args.TEXT)));
        this.dirty = true;
        return "ok";
      } catch (err) { return this._fail("ERR_ADD: " + (err && err.message ? err.message : err)); }
    },
    addBinaryEntry: function (args) {
      var e = this._ensureOpen(); if (e) return e;
      var name = normalizeName(args.PATH); if (!name) return this._fail("ERR_PATH_TRAVERSAL");
      try {
        var buf = base64ToUint8(args.DATA);
        if (buf.length > this.maxSingleBytes) return this._fail("ERR_ENTRY_TOO_LARGE");
        ZIP.add(this.archive, name, buf);
        this.dirty = true;
        return "ok";
      } catch (err) { return this._fail("ERR_ADD_BINARY: " + (err && err.message ? err.message : err)); }
    },
    removeEntry: function (args) {
      var e = this._ensureOpen(); if (e) return e;
      var name = normalizeName(args.PATH); if (!name) return this._fail("ERR_PATH_TRAVERSAL");
      if (!this.entryExists(args)) return "ERR_ENTRY_NOT_FOUND";
      ZIP.remove(this.archive, name);
      this.dirty = true;
      var self = this;
      this._refresh();
      return "ok";
    },
    renameEntry: function (args) {
      var e = this._ensureOpen(); if (e) return e;
      var oldName = normalizeName(args.OLD), newName = normalizeName(args.NEW);
      if (!oldName || !newName) return this._fail("ERR_PATH_TRAVERSAL");
      if (!this.entryExists({ PATH: oldName })) return "ERR_ENTRY_NOT_FOUND";
      if (this.entryExists({ PATH: newName })) return "ERR_ALREADY_EXISTS";
      var self = this;
      return ZIP.read(this.archive, oldName).then(function (bytes) {
        ZIP.remove(self.archive, oldName);
        ZIP.add(self.archive, newName, bytes);
        self.dirty = true;
        self._refresh();
        return "ok";
      }).catch(function (err) { return self._fail("ERR_RENAME: " + (err && err.message ? err.message : err)); });
    },

    // ④ 导出
    exportZip: function (args) {
      var self = this;
      var e = this._ensureOpen(); if (e) return e;
      var name = String(args.NAME || "export.zip").replace(/[\\/:*?"<>|]/g, "_");
      return ZIP.generate(this.archive).then(function (bytes) {
        downloadBlob(bytes, name, "application/zip");
        return "ok";
      }).catch(function (err) { return self._fail("ERR_EXPORT: " + (err && err.message ? err.message : err)); });
    },
    exportZipBase64: function () {
      var self = this;
      var e = this._ensureOpen(); if (e) return e;
      return ZIP.generate(this.archive).then(function (bytes) {
        return uint8ToBase64(bytes);
      }).catch(function (err) { return self._fail("ERR_EXPORT: " + (err && err.message ? err.message : err)); });
    },
    saveZipToFile: function (args) {
      var e = this._ensureOpen(); if (e) return e;
      if (!ZIP.hasFS) return this._fail("ERR_NO_FILESYSTEM");
      var p = String(args.PATH);
      var self = this;
      return ZIP.generate(this.archive).then(function (bytes) {
        try { ZIP.fs.writeFileSync(p, Buffer.from(bytes)); return "ok"; }
        catch (err) { return self._fail("ERR_WRITE: " + (err && err.message ? err.message : err)); }
      }).catch(function (err) { return self._fail("ERR_SAVE: " + (err && err.message ? err.message : err)); });
    },

    // ⑤ 配置 / 诊断
    setZipLimit: function (args) {
      this.maxArchiveBytes = Math.max(0, Number(args.ARCHIVE) || 0);
      this.maxSingleBytes = Math.max(0, Number(args.ENTRY) || 0);
      return "ok";
    },
    lastZipError: function () {
      var v = this.lastError || "";
      this.lastError = "";
      return v;
    }
  };

  Scratch.extensions.register(new ZipExtension());
})(typeof window !== "undefined" ? window.Scratch : (global && global.Scratch));
