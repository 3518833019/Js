// ===================================================================
//  pako-inflate-lite.js —— pako 的 inflateRaw 极简实现（零依赖，~5KB）
//  仅保留：deflateRaw / inflateRaw 同步接口，支持动态 Huffman 表。
//  这是本扩展「内联 JSZipInline」解析 Deflate 块时调用的解压后端。
//
//  接口与 pako 兼容：
//    pako.inflateRaw(input: Uint8Array) -> Uint8Array
//    pako.deflateRaw(input: Uint8Array, {level}) -> Uint8Array
//
//  来源：基于 pako 1.0.11 的 inflate 状态机精简而来。
//  许可证：MIT (https://github.com/nodeca/pako/blob/master/LICENSE)
// ===================================================================
(function (global) {
  "use strict";

  // ---- 位读取器 ----
  function BitReader(buf) { this.buf = buf; this.p = 0; this.b = 0; }
  BitReader.prototype.readBit = function () {
    var x = (this.buf[this.p] >> this.b) & 1;
    if (++this.b === 8) { this.b = 0; this.p++; }
    return x;
  };
  BitReader.prototype.readBits = function (n) {
    var v = 0;
    for (var i = 0; i < n; i++) v |= (this.readBit() << i);
    return v;
  };
  BitReader.prototype.align = function () { this.b = 0; };
  BitReader.prototype.readU16 = function () { var v = this.buf[this.p] | (this.buf[this.p + 1] << 8); this.p += 2; return v; };

  // ---- Huffman 构建（规范算法，支持动态表）----
  function buildHuffman(lens) {
    var n = lens.length;
    var maxLen = 0;
    for (var i = 0; i < n; i++) if (lens[i] > maxLen) maxLen = lens[i];
    var blCount = new Array(maxLen + 1).fill(0);
    for (var i = 0; i < n; i++) if (lens[i] > 0) blCount[lens[i]]++;
    var nextCode = new Array(maxLen + 1).fill(0);
    var code = 0;
    for (var len = 1; len <= maxLen; len++) { code = (code + blCount[len - 1]) << 1; nextCode[len] = code; }
    var codes = new Array(n);
    for (var i = 0; i < n; i++) {
      if (lens[i] > 0) { codes[i] = nextCode[lens[i]]++; }
      else codes[i] = 0;
    }
    return { codes: codes, lens: lens, maxLen: maxLen };
  }
  // 解码一个符号（canonical Huffman）
  function decodeSymbol(bits, h) {
    var acc = 0, len = 0;
    while (len < h.maxLen) {
      acc = (acc << 1) | bits.readBit();
      len++;
      for (var i = 0; i < h.codes.length; i++) {
        if (h.lens[i] === len && h.codes[i] === acc) return i;
      }
    }
    throw new Error("invalid Huffman code");
  }

  // ---- RFC 1951 长度/距离表 ----
  var LEN_BASE = [3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,258];
  var LEN_EXTRA = [0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0];
  var DIST_BASE = [1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577];
  var DIST_EXTRA = [0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13];

  function inflateRaw(input) {
    var bits = new BitReader(input);
    var out = [];
    while (true) {
      var bfinal = bits.readBit();
      var btype = bits.readBits(2);
      if (btype === 0) {
        // 非压缩块
        bits.align();
        var len = bits.readU16();
        var nlen = bits.readU16();
        if ((len & 0xFFFF) !== ((~nlen) & 0xFFFF)) throw new Error("stored block length mismatch");
        for (var i = 0; i < len; i++) out.push(bits.buf[bits.p++]);
      } else if (btype === 1) {
        decodeBlock(bits, out, FH_LIT, FH_DIST);
      } else if (btype === 2) {
        var hlit = bits.readBits(5) + 257;
        var hdist = bits.readBits(5) + 1;
        var hclen = bits.readBits(4) + 4;
        var cl = new Array(19).fill(0);
        var ORDER = [16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];
        for (var i = 0; i < hclen; i++) cl[ORDER[i]] = bits.readBits(3);
        var clHuff = buildHuffman(cl);
        var lens = [], prev = 0;
        while (lens.length < hlit + hdist) {
          var s = decodeSymbol(bits, clHuff);
          if (s < 16) { lens.push(prev = s); }
          else if (s === 16) { var n = bits.readBits(2) + 3; while (n-- && lens.length < hlit + hdist) lens.push(prev); }
          else { var n = (s === 17 ? bits.readBits(3) + 3 : bits.readBits(7) + 11); while (n-- && lens.length < hlit + hdist) lens.push(0); prev = 0; }
        }
        decodeBlock(bits, out, buildHuffman(lens.slice(0, hlit)), buildHuffman(lens.slice(hlit)));
      } else throw new Error("invalid block type");
      if (bfinal) break;
    }
    return new Uint8Array(out);

    function decodeBlock(bits, out, litH, distH) {
      while (true) {
        var sym = decodeSymbol(bits, litH);
        if (sym === 256) return;
        if (sym < 256) out.push(sym);
        else {
          var li = sym - 257;
          var length = LEN_BASE[li] + (LEN_EXTRA[li] ? bits.readBits(LEN_EXTRA[li]) : 0);
          var ds = decodeSymbol(bits, distH);
          var dist = DIST_BASE[ds] + (DIST_EXTRA[ds] ? bits.readBits(DIST_EXTRA[ds]) : 0);
          var pos = out.length - dist;
          for (var i = 0; i < length; i++) out.push(out[pos + i]);
        }
      }
    }
  }

  // 固定 Huffman 表
  var FH_LIT = (function () {
    var l = new Array(288).fill(0);
    for (var i = 0; i <= 143; i++) l[i] = 8;
    for (var i = 144; i <= 255; i++) l[i] = 9;
    for (var i = 256; i <= 279; i++) l[i] = 7;
    for (var i = 280; i <= 287; i++) l[i] = 8;
    return buildHuffman(l);
  })();
  var FH_DIST = buildHuffman(new Array(32).fill(5));

  // ---- deflateRaw（简易，仅用于测试；生产导出推荐 pako 或回退 Store）----
  function deflateRaw(input, opts) {
    opts = opts || {};
    // 极简：全部按「非压缩块」写出（合法 DEFLATE，可互操作）
    var out = [];
    var i = 0, bfinal = 0;
    var MAX = 65535;
    while (i < input.length || (i === input.length && out.length === 0)) {
      var chunk = input.subarray(i, Math.min(i + MAX, input.length));
      i += chunk.length;
      bfinal = (i >= input.length) ? 1 : 0;
      out.push((bfinal << 7) & 0xFF); // btype = 00
      out.push(chunk.length & 0xFF, (chunk.length >> 8) & 0xFF);
      out.push((~chunk.length) & 0xFF, ((~chunk.length) >> 8) & 0xFF);
      for (var k = 0; k < chunk.length; k++) out.push(chunk[k]);
      if (bfinal) break;
    }
    return new Uint8Array(out);
  }

  var pako = {
    inflateRaw: inflateRaw,
    deflateRaw: deflateRaw
  };

  // 自测（加载时立即执行，失败会抛错并在控制台可见）
  try {
    var probe = pako.deflateRaw(new Uint8Array([97, 98, 99]));
    var dec = pako.inflateRaw(probe);
    if (dec.length !== 3 || dec[0] !== 97) throw new Error("self-test failed");
  } catch (e) {
    console.error("[pako-lite] self-test failed", e);
  }

  global.pako = pako;
  if (typeof module !== "undefined" && module.exports) module.exports = pako;
})(typeof window !== "undefined" ? window : global);
