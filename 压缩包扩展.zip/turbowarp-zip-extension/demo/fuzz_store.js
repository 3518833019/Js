// 仅测「非压缩块（btype=00）」的 inflate：验证字节级读取正确
// （动态 Huffman 的长度/距离表解码未完整实现，生产环境应优先用 pako；
//  本扩展导出端仅在无 pako 时回退为 Store，导入端通过此测试保证 Store 块可解）
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const src = fs.readFileSync(path.join(__dirname, "..", "zip-extension.js"), "utf-8");
const start = src.indexOf("// ---------- inflate（RFC 1951，纯 JS）----------");
const end = src.indexOf("// ---------- 条目 / 归档 ----------");
const code = src.slice(start, end);

const sandbox = {
  Uint8Array, ArrayBuffer, DataView, console, Math,
  TextEncoder: require("util").TextEncoder,
  TextDecoder: require("util").TextDecoder,
  module: { exports: {} }, window: {}, global: {}
};
vm.createContext(sandbox);
vm.runInContext(code + "\nmodule.exports = { inflateRaw, BitReader };", sandbox);
const { inflateRaw, BitReader } = sandbox.module.exports;

// 手工构造「非压缩块」：每块最多 65535 字节
function deflateStore(raw) {
  const out = [];
  const MAX = 65535;
  let i = 0, bfinal = 0;
  while (i < raw.length || (i === raw.length && out.length === 0)) {
    const chunk = raw.subarray(i, Math.min(i + MAX, raw.length));
    i += chunk.length;
    bfinal = (i >= raw.length) ? 1 : 0;
    // 块头：1 字节 = bfinal(1) + btype(2) = 0b0000000bfinal_btype1_btype0
    out.push((bfinal << 7) | 0x00); // btype = 00
    // len (LE), nlen (LE, 按位取反)
    const len = chunk.length;
    out.push(len & 0xFF, (len >> 8) & 0xFF);
    out.push((~len) & 0xFF, ((~len) >> 8) & 0xFF);
    for (let k = 0; k < chunk.length; k++) out.push(chunk[k]);
    if (bfinal) break;
  }
  return new Uint8Array(out);
}

const cases = [];
cases.push(Buffer.from("Hello Store block!"));
cases.push(Buffer.from("你好 🌍 世界"));
cases.push(Buffer.from("aaaaaaaaaaaaa"));
cases.push(Buffer.from([0x00, 0x01, 0xFF, 0xFE, 0x80]));
cases.push(Buffer.from(""));
// 跨越 65535 边界
const big = Buffer.alloc(70000);
for (let i = 0; i < big.length; i++) big[i] = i & 0xFF;
cases.push(big);

let pass = 0, fail = 0;
for (let i = 0; i < cases.length; i++) {
  const raw = cases[i];
  const comp = deflateStore(raw);
  try {
    const got = inflateRaw(comp);
    const ok = got.length === raw.length && Buffer.from(got).equals(raw);
    if (ok) pass++;
    else { fail++; console.error(`❌ 不匹配 case=${i} len=${raw.length} got=${got.length}`); }
  } catch (e) {
    fail++;
    console.error(`❌ 抛错 case=${i}:`, e.message);
  }
}
console.log(`\n非压缩块测试：通过 ${pass} / 失败 ${fail}`);
process.exit(fail > 0 ? 1 : 0);
