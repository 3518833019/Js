# CHANGELOG

## v1.0.0（首发）

### 功能
- 23 个积木，覆盖 ZIP 完整 CRUD：
  - **导入**：`从文件打开 ZIP`（系统文件选择器）、`创建空 ZIP`、`从 Base64 打开 ZIP [DATA]`
  - **读取**：`ZIP 条目数`、`索引 [INDEX] 的条目名`、`条目列表（JSON）`、`ZIP 包含条目 [PATH]？`、`条目 [PATH] 的未压缩大小`、`条目 [PATH] 是文件夹？`、`读取 [PATH] 为文本`、`读取 [PATH] 为 Base64`
  - **写入**：`添加文本条目 [PATH] 内容 [TEXT]`、`添加二进制条目 [PATH] 内容 Base64 [DATA]`、`删除条目 [PATH]`、`重命名条目 [OLD] 为 [NEW]`
  - **导出**：`下载 ZIP 为 [NAME]`（Blob 下载，跨平台）、`ZIP 的 Base64`、`将 ZIP 保存到 [PATH]`（仅 Desktop 非沙箱）
  - **诊断**：`ZIP 引擎`、`可使用本地文件系统？`、`已打开 ZIP？`、`设置最大压缩包字节 [ARCHIVE] 最大单文件字节 [ENTRY]`、`最后 ZIP 错误`
- 双引擎运行时降级：
  - **Desktop 非沙箱**：探测 `require("adm-zip")` + `fs` → 同步读写、可直接存盘
  - **网页版 / 沙箱**：内联 `JSZipInline`（含 RFC 1951 inflate 子集） + `<input type="file">` + `Blob` 下载
- 安全：Zip-Slip 路径遍历防护（`../`、绝对路径、NUL 拒绝）、压缩炸弹阈值、二进制/文本显式分流、UTF-8 文件名标志位、错误码替代抛错。

### 测试
- `demo/verify.sh`：一键跑 5 项回归
- `demo/test_e2e.js`：完整 CRUD + 系统 `unzip` 校验
- `demo/test_roundtrip_deflate.js`：导出 ZIP → 系统 unzip 内容比对
- `demo/test_realzip.js`：真实 `zip` 命令生成的 Deflate ZIP 导入
- `demo/fuzz_store.js`：inflate 非压缩块模糊测试（含 65535 字节边界、中文、二进制、空）
- `demo/make_store_zip.js` / `make_sample_minizip.js`：生成合法 ZIP 样本

### 已知限制
- 内联 inflate 对**动态 Huffman 表**的解码存在边界问题，不能保证解压任意 Deflate 块。
  **缓解**：Desktop 端导入走 Node `zlib.inflateRawSync`（已实装）；网页端若加载了 pako 则自动启用；否则仅 Store 块可解。
- 导出端若无 pako 则回退为 Store（不压缩但可解压）。
- 未实现：ZIP 密码、ZIP64、符号链接保留、资源叉。
