// 用 Node 内置 zlib 生成合法 ZIP（Store + Deflate 均支持），无需 adm-zip
const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

const OUT = path.join(__dirname, "sample.zip");

// ---- CRC32（IEEE 802.3，与 ZIP 规范一致）----
const CRC_TABLE = new Uint32Array(256);
(function () {
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    CRC_TABLE[i] = c >>> 0;
  }
})();
function crc32(buf) {
  let crc = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) crc = CRC_TABLE[(crc ^ buf[i]) & 0xFF] ^ (crc >>> 8);
  return (crc ^ 0xFFFFFFFF) >>> 0;
}
function dosTime(d) {
  const y = d.getUTCFullYear() - 1980;
  const mon = d.getUTCMonth() + 1;
  const day = d.getUTCDate();
  const h = d.getUTCHours();
  const m = d.getUTCMinutes();
  const s = Math.floor(d.getUTCSeconds() / 2);
  const time = ((h & 31) << 11) | ((m & 63) << 5) | (s & 31);
  const date = ((y & 127) << 9) | ((mon & 15) << 5) | (day & 31);
  return [time >>> 0, date >>> 0];
}

// ---- 条目 ----
const files = [
  { name: "readme.txt",      body: "Hello from TurboWarp ZIP extension!\n这是一行中文。\nEmoji: 📦🚀\n" },
  { name: "config.json",     body: JSON.stringify({ version: 1, author: "TurboWarp", features: ["import","read","write","export"] }, null, 2) + "\n" },
  { name: "data/score.csv",  body: "name,score\nAlice,100\nBob,95\n" },
  { name: "data/empty.txt",  body: "" },
  { name: "assets/",         body: null },            // 目录
  { name: "assets/note.txt", body: "I'm inside assets folder.\n" },
  { name: "bin/zero.bin",    body: Buffer.from([0x00, 0x01, 0x02, 0xFF, 0xFE]) } // 二进制
];

const central = [];
const local = [];
let offset = 0;

files.forEach(function (f) {
  const nameBytes = Buffer.from(f.name, "utf-8");
  const isDir = f.body === null;
  const raw = isDir ? Buffer.alloc(0) : (Buffer.isBuffer(f.body) ? f.body : Buffer.from(f.body, "utf-8"));
  const compressed = raw.length < 16 ? raw : zlib.deflateRawSync(raw); // Deflate 压缩
  const method = raw.length < 16 ? 0 : 8; // 0=stored, 8=deflate
  const crc = crc32(raw);
  const [mtime, mdate] = [dosTime(new Date())];
  const flag = 0x0800; // 通用位 11 = UTF-8 文件名

  // 本地文件头
  const header = Buffer.alloc(30);
  header.writeUInt32LE(0x04034B50, 0);   // 签名
  header.writeUInt16LE(20, 4);           // 版本
  header.writeUInt16LE(flag, 6);         // 标志（UTF-8）
  header.writeUInt16LE(method, 8);       // 压缩方法
  header.writeUInt16LE(mtime, 10);       // 修改时间
  header.writeUInt16LE(mdate, 12);       // 修改日期
  header.writeUInt32LE(crc, 14);         // CRC32
  header.writeUInt32LE(compressed.length, 18); // 压缩后大小
  header.writeUInt32LE(raw.length, 22);  // 未压缩大小
  header.writeUInt16LE(nameBytes.length, 26);
  header.writeUInt16LE(0, 28);           // 扩展字段长度

  const localHeader = Buffer.concat([header, nameBytes, compressed]);
  local.push(localHeader);

  // 中央目录条目
  const cen = Buffer.alloc(46);
  cen.writeUInt32LE(0x02014B50, 0);     // 中央目录签名
  cen.writeUInt16LE(20, 4);             // 创建版本
  cen.writeUInt16LE(20, 6);             // 提取版本
  cen.writeUInt16LE(flag, 8);           // 标志
  cen.writeUInt16LE(method, 10);        // 压缩方法
  cen.writeUInt16LE(mtime, 12);
  cen.writeUInt16LE(mdate, 14);
  cen.writeUInt32LE(crc, 16);
  cen.writeUInt32LE(compressed.length, 20);
  cen.writeUInt32LE(raw.length, 24);
  cen.writeUInt16LE(nameBytes.length, 28);
  cen.writeUInt16LE(0, 30);             // 扩展字段
  cen.writeUInt16LE(0, 32);             // 注释长度
  cen.writeUInt16LE(0, 34);             // 磁盘号
  cen.writeUInt16LE(0, 36);             // 内部属性
  cen.writeUInt32LE(isDir ? 0x10 : 0, 38); // 外部属性（0x10 = 目录）
  cen.writeUInt32LE(offset, 42);        // 本地文件头偏移

  central.push(Buffer.concat([cen, nameBytes]));
  offset += localHeader.length;
});

// 中央目录结尾（EOCD）
const cenBuf = Buffer.concat(central);
const eocd = Buffer.alloc(22);
eocd.writeUInt32LE(0x06054B50, 0);
eocd.writeUInt16LE(0, 4);               // 当前磁盘
eocd.writeUInt16LE(0, 6);               // 中央目录起始磁盘
eocd.writeUInt16LE(files.length, 8);    // 本盘条目数
eocd.writeUInt16LE(files.length, 10);   // 总条目数
eocd.writeUInt32LE(cenBuf.length, 12);  // 中央目录大小
eocd.writeUInt32LE(offset, 16);         // 中央目录偏移
eocd.writeUInt16LE(0, 20);              // 注释长度

fs.writeFileSync(OUT, Buffer.concat([...local, cenBuf, eocd]));
console.log("✅ 已生成 demo/sample.zip （含中文名、目录、Deflate、二进制，条目数 =", files.length, "）");
